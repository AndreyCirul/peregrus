﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace peregrusochnie
{
    public partial class registration : Window
    {
        private const string initVector = "pemgail9uzpgzl88";
        private const int keysize = 256;
        private string encriptPass = "P@$$w0rd";
        private MainWindow main;
        private string conectionString;
        private bool closing = false;

        public registration(MainWindow main, string conectionString)
        {
            InitializeComponent();
            this.main = main;
            this.conectionString = conectionString;
        }

        public static string EncryptString(string plainText, string passPhrase)
        {
            byte[] initVectorBytes = Encoding.UTF8.GetBytes(initVector);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] cipherTextBytes = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(cipherTextBytes);
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
                main.IsEnabled = true;             
        }
   

        private void back_Click(object sender, RoutedEventArgs e)
        {     
            this.Close();
        } 

        private void ownerReg_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection con = new SqlConnection(conectionString);
            SqlDataAdapter da;
            SqlDataAdapter daWorkers;
            DataTable usersDT = new DataTable();
            DataTable workersDT = new DataTable();       

            con.Open();
            da = new SqlDataAdapter("select * from cargoOwners", con);
            da.Fill(usersDT);

            daWorkers = new SqlDataAdapter("select * from workers", con);
            daWorkers.Fill(workersDT); 

            bool nameOwned = false;
            if (ownerLog.Text != "" && ownerPass.Text != "")
            {
                for (int i = 0; i < usersDT.Rows.Count; i++)
                {
                    if (EncryptString(ownerLog.Text, encriptPass) == usersDT.Rows[i][1].ToString())
                    {
                        nameOwned = true;
                        break;
                    }
                }

                for (int i = 0; i < workersDT.Rows.Count; i++)
                {
                    if (EncryptString(ownerLog.Text, encriptPass) == workersDT.Rows[i][1].ToString())
                    {
                        nameOwned = true;
                        break;
                    }
                }

                if (!nameOwned)
                {
                    int newID = 0;
                    for (int i = 0; i < usersDT.Rows.Count; i++)
                    {
                        if ((i + 1).ToString() != usersDT.Rows[i][0].ToString())
                        {
                            newID = i + 1;
                            break;
                        }
                    }
                    if (newID == 0)
                    {
                        usersDT.Rows.Add(usersDT.Rows.Count + 1);                      
                        main.userID = usersDT.Rows.Count;
                    }
                    else
                    {
                        usersDT.Rows.Add(newID);
                        main.userID = newID;
                    }

                    int id = usersDT.Rows.Count - 1;

                    usersDT.Rows[id][1] = EncryptString(ownerLog.Text, encriptPass);
                    usersDT.Rows[id][2] = EncryptString(ownerPass.Text, encriptPass);     

                    SqlCommandBuilder cb = new SqlCommandBuilder(da);
                    da.Update(usersDT);

                    main.userTypeChanged("cargoOwner");


                    closing = true;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Имя занято");
                }
            }
            else
            {
                MessageBox.Show("Поля не заполнены");
            }
        }

        private void agentReg_Click(object sender, RoutedEventArgs e)
        {
            workersReg(agentLog.Text, agentPass.Text, agentCard.Text, "agent");
        }

        private void storReg_Click(object sender, RoutedEventArgs e)
        {
            workersReg(storLog.Text, storPass.Text, storCard.Text, "warehousingSevise");
        }

        private void servisReg_Click(object sender, RoutedEventArgs e)
        {
            workersReg(servisLog.Text, servisPass.Text, servisCard.Text, "customerService");
        }

        private void workersReg(string log, string pass, string cardID, string type)
        {
            SqlConnection con = new SqlConnection(conectionString);
            SqlDataAdapter da;
            SqlDataAdapter daWorkers;
            DataTable usersDT = new DataTable();
            DataTable workersDT = new DataTable();

            con.Open();
            da = new SqlDataAdapter("select * from cargoOwners", con);
            da.Fill(usersDT);

            daWorkers = new SqlDataAdapter("select * from workers", con);
            daWorkers.Fill(workersDT);

            bool nameOwned = false;
            bool cardOwned = false;
            if (log != "" && pass != "")
            {
                for (int i = 0; i < usersDT.Rows.Count; i++)
                {
                    if (EncryptString(log, encriptPass) == usersDT.Rows[i][1].ToString())
                    {
                        nameOwned = true;
                        break;
                    }
                }

                for (int i = 0; i < workersDT.Rows.Count; i++)
                {
                    if (EncryptString(log, encriptPass) == workersDT.Rows[i][1].ToString())
                    {
                        nameOwned = true;
                        break;
                    }
                }

                for (int i = 0; i < workersDT.Rows.Count; i++)
                {
                    if (EncryptString(cardID, encriptPass) == workersDT.Rows[i][3].ToString() && EncryptString(type, encriptPass) == workersDT.Rows[i][4].ToString())
                    {
                        cardOwned = true;
                        break;
                    }
                }

                if (!nameOwned)
                {
                    if (!cardOwned)
                    {
                        int newID = 0;
                        for (int i = 0; i < workersDT.Rows.Count; i++)
                        {
                            if ((i + 1).ToString() != workersDT.Rows[i][0].ToString())
                            {
                                newID = i + 1;
                                break;
                            }
                        }
                        if (newID == 0)
                        {
                            workersDT.Rows.Add(workersDT.Rows.Count + 1);
                            main.userID = workersDT.Rows.Count + 1;
                        }
                        else
                        {
                            workersDT.Rows.Add(newID);
                            main.userID = newID;
                        }

                        int id = workersDT.Rows.Count - 1;

                        workersDT.Rows[id][1] = EncryptString(log, encriptPass);
                        workersDT.Rows[id][2] = EncryptString(pass, encriptPass);
                        workersDT.Rows[id][3] = EncryptString(cardID, encriptPass);
                        workersDT.Rows[id][4] = EncryptString(type, encriptPass);

                        SqlCommandBuilder cb = new SqlCommandBuilder(daWorkers);
                        daWorkers.Update(workersDT);

                        main.userTypeChanged(type);


                        closing = true;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Карточка уже зарегестрирована");
                    }
                }
                else
                {
                    MessageBox.Show("Имя занято");
                }
            }
            else
            {
                MessageBox.Show("Поля не заполнены");
            }

        }
    }
}
