﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace peregrusochnie
{

    public partial class tehnik : Window
    {
        MainWindow main;
        string connectionString;

        public tehnik(MainWindow main, string connectionString)
        {
            InitializeComponent();

            this.main = main;
            this.connectionString = connectionString;

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();

            DataTable autoT = new DataTable();

            autoT.Columns.Add("Тип автомобиля");
            autoT.Columns.Add("Длина, м");
            autoT.Columns.Add("Ширина, м");
            autoT.Columns.Add("Высота, м");
            autoT.Columns.Add("Грузоподъемность, т");
            autoT.Columns.Add("Тип кузова");
            autoT.Columns.Add("Количество, шт");
            autoT.Columns.Add("Свободно, шт");

            auto.ItemsSource = autoT.DefaultView;

            DataTable raiwayT = new DataTable();

            raiwayT.Columns.Add("Тип вагона");
            raiwayT.Columns.Add("длина, м");
            raiwayT.Columns.Add("ширина, м");
            raiwayT.Columns.Add("высота, м");
            raiwayT.Columns.Add("тоннаж, т");
            raiwayT.Columns.Add("вид вагона");
            raiwayT.Columns.Add("тип груза");
            raiwayT.Columns.Add("количество, шт");
            raiwayT.Columns.Add("свободно, шт");

            railway.ItemsSource = raiwayT.DefaultView;

            DataTable shipT = new DataTable();

            shipT.Columns.Add("Название");
            shipT.Columns.Add("Тип судна");
            shipT.Columns.Add("Год постройки");
            shipT.Columns.Add("Длина");
            shipT.Columns.Add("Ширина");
            shipT.Columns.Add("Снаряженный вес");
            shipT.Columns.Add("Макс осадка");
            shipT.Columns.Add("Макс грузоподъемность");
            shipT.Columns.Add("Флаг");
            shipT.Columns.Add("Статус");

            ships.ItemsSource = shipT.DefaultView;

            SqlDataAdapter autoDA = new SqlDataAdapter("select * from auto", con);
            DataTable autoDT = new DataTable();
            autoDA.Fill(autoDT);
            
            for(int i=0; i<autoDT.Rows.Count; i++)
            {
                int free =Convert.ToInt32( autoDT.Rows[i]["count"]);

                if (main.appID != 0)
                {
                    SqlDataAdapter da = new SqlDataAdapter("select count from usedTransport where transportType='auto' and transportId=" + autoDT.Rows[i]["Id"] + "and ((dateFrom > '" + main.date.SelectedDate.Value.ToShortDateString() + "' and dateFrom < '" + main.dateTo.SelectedDate.Value.ToShortDateString() + "') or(dateTo > '" + main.date.SelectedDate.Value.ToShortDateString() + "' and dateTo < '" + main.dateTo.SelectedDate.Value.ToShortDateString() + "'))", con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    foreach (DataRow row in dt.Rows)
                    {
                        free -= Convert.ToInt32(row[0]);
                    }
                }
                autoT.Rows.Add(autoDT.Rows[i]["autoType"], autoDT.Rows[i]["length"], autoDT.Rows[i]["wight"], autoDT.Rows[i]["height"], autoDT.Rows[i]["liftingCapasity"], autoDT.Rows[i]["bodyType"], autoDT.Rows[i]["count"], free);
            }

            SqlDataAdapter railwayDA = new SqlDataAdapter("select * from railwayCarriage", con);
            DataTable railwayDT = new DataTable();
            railwayDA.Fill(railwayDT);

            for (int i = 0; i < railwayDT.Rows.Count; i++)
            {
                int free = Convert.ToInt32(autoDT.Rows[i]["count"]);
                if (main.appID != 0)
                {
                    SqlDataAdapter da = new SqlDataAdapter("select count from usedTransport where transportType='railway' and transportId=" + railwayDT.Rows[i]["Id"] + "and ((dateFrom >= '" + main.date.SelectedDate.Value.ToShortDateString() + "' and dateFrom <= '" + main.dateTo.SelectedDate.Value.ToShortDateString() + "') or(dateTo >= '" + main.date.SelectedDate.Value.ToShortDateString() + "' and dateTo <= '" + main.dateTo.SelectedDate.Value.ToShortDateString() + "'))", con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    foreach (DataRow row in dt.Rows)
                    {
                        free -= Convert.ToInt32(row[0]);
                    }

                }
                raiwayT.Rows.Add(railwayDT.Rows[i]["wagonType"], railwayDT.Rows[i]["length"], railwayDT.Rows[i]["width"], railwayDT.Rows[i]["height"], railwayDT.Rows[i]["tonnage"], railwayDT.Rows[i]["type"], railwayDT.Rows[i]["cargoType"], railwayDT.Rows[i]["count"], free);
            }

            SqlDataAdapter shipDA = new SqlDataAdapter("select * from ships", con);
            DataTable shipyDT = new DataTable();
            shipDA.Fill(shipyDT);

            for (int i = 0; i < shipyDT.Rows.Count; i++)
            {
                string status = "Свободен";
                if (main.appID != 0)
                {
                    SqlDataAdapter da = new SqlDataAdapter("select count from usedTransport where transportType='ship' and transportId=" + shipyDT.Rows[i]["Id"] + "and ((dateFrom >= '" + main.date.SelectedDate.Value.ToShortDateString() + "' and dateFrom <= '" + main.dateTo.SelectedDate.Value.ToShortDateString() + "') or(dateTo >= '" + main.date.SelectedDate.Value.ToShortDateString() + "' and dateTo <= '" + main.dateTo.SelectedDate.Value.ToShortDateString() + "'))", con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    if (dt.Rows.Count != 0)
                        status = "Занят";
                }

                shipT.Rows.Add(shipyDT.Rows[i]["name"],  shipyDT.Rows[i]["type"], shipyDT.Rows[i]["year"], shipyDT.Rows[i]["length"], shipyDT.Rows[i]["width"], shipyDT.Rows[i]["curbWeight"], shipyDT.Rows[i]["maxDraft"], shipyDT.Rows[i]["maxWeight"], shipyDT.Rows[i]["flag"], status);
            }

            if (main.appID != 0)
            {
                SqlDataAdapter cda = new SqlDataAdapter("select count from usedTransport where transportType='railway' and ((dateFrom >= '" + main.date.SelectedDate.Value.ToShortDateString() + "' and dateFrom <= '" + main.dateTo.SelectedDate.Value.ToShortDateString() + "') or(dateTo >= '" + main.date.SelectedDate.Value.ToShortDateString() + "' and dateTo <= '" + main.dateTo.SelectedDate.Value.ToShortDateString() + "'))", con);
                DataTable cdt = new DataTable();
                cda.Fill(cdt);

                locomotivs.Text = (15 - cdt.Rows.Count).ToString();
            }
            locomotivs.Text = "15";
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            this.Close();  
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            main.IsEnabled = true;
        }
    }
}
