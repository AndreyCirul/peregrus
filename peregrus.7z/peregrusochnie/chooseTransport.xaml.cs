﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace peregrusochnie
{

    public partial class chooseTransport : Window
    {
        prichal pr;
        MainWindow main;
        string connectionString;
        DataTable warhoses = new DataTable();
        int number;

        public chooseTransport(prichal pr, MainWindow main, string connectionString, int number)
        {
            InitializeComponent();

            this.pr = pr;
            this.main = main;
            this.connectionString = connectionString;
            this.number = number;

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();

            SqlDataAdapter da = new SqlDataAdapter("select indoorWarehouse, outdoorWarehouse from berthes where \"№\"="+number.ToString(), con);
            da.Fill(warhoses);

            if(main.cargoType.SelectedValue.ToString()== "Зерно" || main.cargoType.SelectedValue.ToString() == "Сыпучий" || main.cargoType.SelectedValue.ToString() == "Нефтепродукты" || main.cargoType.SelectedValue.ToString() == "Газ" || main.cargoType.SelectedValue.ToString() == "Наливной")
            {
                if (warhoses.Rows[0][0].ToString()=="" || warhoses.Rows[0][0]==null)
                {
                    use.IsEnabled = false;
                }
            }

            if ( main.cargoType.SelectedValue.ToString() == "Нефтепродукты" || main.cargoType.SelectedValue.ToString() == "Газ" || main.cargoType.SelectedValue.ToString() == "Наливной")
            {
                autoB.IsEnabled = false;
            }

            if ((warhoses.Rows[0][0].ToString()=="" || Convert.ToDouble(main.tonns) > Convert.ToInt32(warhoses.Rows[0][0].ToString().Split(' ')[0].Replace(Environment.NewLine, string.Empty))) && (warhoses.Rows[0][1].ToString()=="" || main.tonns> Convert.ToInt32(warhoses.Rows[0][1].ToString().Split(' ')[0].Replace(Environment.NewLine, string.Empty))))
                use.IsEnabled = false;

            if (main.cargoType.SelectedValue.ToString() == "Зерно" || main.cargoType.SelectedValue.ToString() == "Сыпучий" || main.cargoType.SelectedValue.ToString() == "Металл")
            {
                platform.IsEnabled = true;
            }
  
            con.Close();

            if (pr.extra.Text != "")
            {
                string[] extras = pr.extra.Text.Split(',');
                foreach(string ext in extras)
                {
                    if (ext=="жд")
                    {
                        SqlDataAdapter railWayDA = new SqlDataAdapter("select id from usedTransport where transportType='railway'", con);
                        DataTable railwayDT = new DataTable();
                        railWayDA.Fill(railwayDT);
                        if (railwayDT.Rows.Count<15)
                        {
                            railwayB.IsEnabled = true;
                        }
                    }
                }
            }

            con.Close();
        }

        private void use_Checked(object sender, RoutedEventArgs e)
        {

            if (warhoses.Rows[0][0].ToString() != "" && warhoses.Rows[0][0] != null)
            {
               
                if (Convert.ToInt32(warhoses.Rows[0][0].ToString().Replace(Environment.NewLine, string.Empty).Split(' ')[0])>main.tonns)
                {
                    close.IsEnabled = true;
                }
            }

            if (warhoses.Rows[0][1].ToString() != "" && warhoses.Rows[0][1] != null)
            {

                if (Convert.ToInt32(warhoses.Rows[0][1].ToString().Replace(Environment.NewLine, string.Empty).Split(' ')[0]) > main.tonns && main.cargoType.SelectedValue.ToString() != "Зерно" && main.cargoType.SelectedValue.ToString() != "Сыпучий ")
                {
                    open.IsEnabled = true;
                    open.IsChecked = true;
                }
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            pr.Show();
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            if (autoB.IsChecked==true)
            {
                auto auto = new auto(this, pr, main, connectionString, number);
                auto.Show();
                this.Hide();
            }
            if (railwayB.IsChecked==true)
            {
                railway railway = new railway(this, pr, main, connectionString, number);
                railway.Show();
                this.Hide();
            }
            if (shipB.IsChecked==true)
            {
                ship ship = new ship(this, pr, main, connectionString, number);
                ship.Show();
                this.Hide();
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            pr.Show();
        }
    }
}
