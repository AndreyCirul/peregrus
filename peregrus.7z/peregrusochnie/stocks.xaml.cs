﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace peregrusochnie
{
    public partial class stocks : Window
    {
        MainWindow main;
        string connectionString;


        public stocks(MainWindow main, string connectionString)
        {
            InitializeComponent();


            this.main = main;
            this.connectionString = connectionString;

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();

            SqlDataAdapter openDA = new SqlDataAdapter("select distinct outdoorWarehouse, extra, term, \"cargo type\", \"cargo sort\"  from berthes where outdoorWarehouse is not NULL order by term", con);
            DataTable openDT = new DataTable();
            openDA.Fill(openDT);

            SqlDataAdapter closeDA = new SqlDataAdapter("select distinct indoorWarehouse, extra, term, \"cargo type\", \"cargo sort\"  from berthes where indoorWarehouse is not NULL order by term", con);
            DataTable closeDT = new DataTable();
            closeDA.Fill(closeDT);

            DataTable open = new DataTable();
            DataTable close = new DataTable();

            open.Columns.Add("Терминал");
            open.Columns.Add("Тип груза");
            open.Columns.Add("Свободное место(м)");
            open.Columns.Add("Общий размер(м)");
            open.Columns.Add("Дополнительно");

            openGrid.ItemsSource = open.DefaultView;



            for (int i = 0; i < openDT.Rows.Count; i++)
            {
                string[] size = openDT.Rows[i]["outdoorWarehouse"].ToString().Split(' ');
                if (size.Length == 2)
                    size[0] = Convert.ToInt32(main.teuToM3(Convert.ToDouble(size[0]))).ToString();

                int freeSpace = Convert.ToInt32(size[0]);

                if (size.Length == 2)
                    freeSpace = Convert.ToInt32(main.m3ToTeu(Convert.ToDouble(freeSpace)));

                if (main.appID != 0)
                {
                    SqlDataAdapter appDA = new SqlDataAdapter("select cargoSize, pier, cargoType from application where storageType='open' and ((date>='" + main.date.SelectedDate.Value.ToShortDateString() + "' and Date<='" + main.dateTo.SelectedDate.Value.ToShortDateString() + "') or ( DateTo>='" + main.date.SelectedDate.Value.ToShortDateString() + "' and DateTo<='" + main.dateTo.SelectedDate.Value.ToShortDateString() + "'))", con);
                    DataTable appDT = new DataTable();
                    appDA.Fill(appDT);

                    SqlDataAdapter pDA = new SqlDataAdapter("select \"№\", term from berthes", con);
                    DataTable pDT = new DataTable();
                    pDA.Fill(pDT);

                    for (int j = 0; j < appDT.Rows.Count; j++)
                    {
                        for (int k = 0; k < pDT.Rows.Count; k++)
                        {

                            if (appDT.Rows[j]["pier"].ToString() == pDT.Rows[k]["№"].ToString() && pDT.Rows[k]["term"].ToString() == openDT.Rows[i]["term"].ToString())
                            {
                                if (main.cargoType.SelectedValue.ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "") != "Контейнер")
                                    freeSpace -= Convert.ToInt32(appDT.Rows[j]["cargoSize"]);
                                else
                                    freeSpace -= Convert.ToInt32(main.teuToM3(Convert.ToDouble(appDT.Rows[j]["cargoSize"])));
                            }
                        }
                    }
                }
                open.Rows.Add(openDT.Rows[i]["term"].ToString().Replace(Environment.NewLine, string.Empty), openDT.Rows[i]["cargo type"].ToString().Replace(Environment.NewLine, string.Empty), freeSpace.ToString(), openDT.Rows[i]["outdoorWarehouse"].ToString().Replace(Environment.NewLine, string.Empty), openDT.Rows[i]["extra"].ToString().Replace(Environment.NewLine, string.Empty));
            }

            close.Columns.Add("Терминал");
            close.Columns.Add("Тип груза");
            close.Columns.Add("Свободное место(м)");
            close.Columns.Add("Общий размер(м)");
            close.Columns.Add("Дополнительно");

            closeGrid.ItemsSource = close.DefaultView;

            for (int i = 0; i < closeDT.Rows.Count; i++)
            {

                string[] size = closeDT.Rows[i]["indoorWarehouse"].ToString().Split(' ');
                if (size.Length == 2)
                    size[0] = Convert.ToInt32(main.teuToM3(Convert.ToDouble(size[0]))).ToString();

                int freeSpace = Convert.ToInt32(size[0]); ;

                if (size.Length == 2)
                    freeSpace = Convert.ToInt32(main.m3ToTeu(Convert.ToDouble(freeSpace)));

                if (main.appID != 0)
                {
                    SqlDataAdapter appDA = new SqlDataAdapter("select cargoSize, pier, cargoType from application where storageType='close' and ((date>='" + main.date.SelectedDate.Value.ToShortDateString() + "' and Date<='" + main.dateTo.SelectedDate.Value.ToShortDateString() + "') or ( DateTo>='" + main.date.SelectedDate.Value.ToShortDateString() + "' and DateTo<='" + main.dateTo.SelectedDate.Value.ToShortDateString() + "'))", con);
                    DataTable appDT = new DataTable();
                    appDA.Fill(appDT);


                    SqlDataAdapter pDA = new SqlDataAdapter("select \"№\", term from berthes", con);
                    DataTable pDT = new DataTable();
                    pDA.Fill(pDT);


                    for (int j = 0; j < appDT.Rows.Count; j++)
                    {
                        for (int k = 0; k < pDT.Rows.Count; k++)
                        {
                            if (appDT.Rows[j]["pier"].ToString() == pDT.Rows[k]["№"].ToString() && pDT.Rows[k]["temp"].ToString() == closeDT.Rows[i]["term"].ToString())
                            {
                                if (main.cargoType.SelectedValue.ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "") != "Контейнер")
                                    freeSpace -= Convert.ToInt32(appDT.Rows[j]["cargoSize"]);
                                else
                                    freeSpace -= Convert.ToInt32(main.teuToM3(Convert.ToDouble(appDT.Rows[j]["cargoSize"])));
                            }
                        }
                    }
                }

                close.Rows.Add(closeDT.Rows[i]["term"].ToString().Replace(Environment.NewLine, string.Empty), closeDT.Rows[i]["cargo type"].ToString().Replace(Environment.NewLine, string.Empty), freeSpace, closeDT.Rows[i]["indoorWarehouse"].ToString().Replace(Environment.NewLine, string.Empty), closeDT.Rows[i]["extra"].ToString().Replace(Environment.NewLine, string.Empty));
            }

            con.Close();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            main.IsEnabled = true;
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
