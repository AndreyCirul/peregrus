﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace peregrusochnie
{
    /// <summary>
    /// Логика взаимодействия для showDoc.xaml
    /// </summary>
    public partial class showDoc : Window
    {
        MainWindow main;

        public showDoc(MainWindow main)
        {
            InitializeComponent();

            this.main = main;

            if (main.docImage!=null)
            {
                MemoryStream ms = new MemoryStream();
                main.docImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                ms.Position = 0;

                var bi = new BitmapImage();
                bi.BeginInit();
                bi.CacheOption = BitmapCacheOption.OnLoad;
                bi.StreamSource = ms;
                bi.EndInit();

                image.Source = bi;
            }
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            main.IsEnabled = true;
        }
    }
}
