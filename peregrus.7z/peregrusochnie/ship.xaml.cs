﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace peregrusochnie
{

    public partial class ship : Window
    {
        chooseTransport trans;
        prichal pr;
        MainWindow main;
        string connectionString;
        int number;
        int transID;
        SqlConnection con;

        public ship(chooseTransport trans, prichal pr, MainWindow main, string connectionString, int number)
        {
            InitializeComponent();

            this.trans = trans;
            this.pr = pr;
            this.main = main;
            this.connectionString = connectionString;
            this.number = number;

            con = new SqlConnection(connectionString);

            con.Open();

            SqlDataAdapter da = new SqlDataAdapter("select name from ships where length<="+pr.length.Text.Replace(",",".")+" and maxDraft<="+pr.length.Text.Replace(",", ".") + " and maxWeight>="+main.tonns.ToString(), con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            foreach(DataRow row in dt.Rows)
            {
                name.Items.Add(row["name"].ToString().Replace(Environment.NewLine, string.Empty));
            }

            con.Close();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            trans.Show();
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            if (name.SelectedIndex != -1)
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();

                SqlDataAdapter da = new SqlDataAdapter("select * from application where id=" + main.appID.ToString(), con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dt.Rows[0]["agentId"] = main.userID;
                dt.Rows[0]["timeTo"] = main.time.Text;
                dt.Rows[0]["pier"] = number;
                dt.Rows[0]["usePlatform"] = trans.platform.IsChecked;
                if (dt.Rows[0]["agentPrise"].ToString() != "")
                {
                    dt.Rows[0]["status"] = "Ожидает проверки от служб";
                }

                if (trans.use.IsChecked == true)
                {
                    if (trans.close.IsChecked == true)
                    {
                        dt.Rows[0]["storageType"] = "close";
                    }
                    else
                    {
                        dt.Rows[0]["storageType"] = "open";
                    }
                }
                else
                {
                    dt.Rows[0]["storageType"] = "no";
                }


                SqlCommandBuilder cb = new SqlCommandBuilder(da);
                da.Update(dt);

                SqlDataAdapter checkDA = new SqlDataAdapter("select * from usedTransport where ownerId=" + main.appID.ToString(), con);
                DataTable checkDT = new DataTable();
                checkDA.Fill(checkDT);

                if (checkDT.Rows.Count == 0)
                {
                    SqlDataAdapter transDA = new SqlDataAdapter("select * from usedTransport", con);
                    DataTable transDT = new DataTable();
                    transDA.Fill(transDT);

                    int newID = 0;
                    for (int i = 0; i < transDT.Rows.Count; i++)
                    {
                        if ((i + 1).ToString() != transDT.Rows[i][0].ToString())
                        {
                            newID = i + 1;
                            break;
                        }
                    }

                    if (newID == 0)
                    {
                        transDT.Rows.Add(transDT.Rows.Count + 1, "ship", transID, "1", main.appID, main.date.SelectedDate.Value.ToShortDateString(), main.dateTo.SelectedDate.Value.ToShortDateString());
                    }
                    else
                    {
                        transDT.Rows.Add(newID, "ship", transID, "1", main.appID, main.date.SelectedDate.Value.ToShortDateString(), main.dateTo.SelectedDate.Value.ToShortDateString());
                    }

                    MessageBox.Show(transDT.Rows.Count.ToString());

                    SqlCommandBuilder transCB = new SqlCommandBuilder(transDA);
                    transDA.Update(transDT);
                }
                else
                {
                    checkDT.Rows[0]["transportType"] = "ship";
                    checkDT.Rows[0]["transportId"] = transID;
                    checkDT.Rows[0]["count"] = "1";
                    checkDT.Rows[0]["dateFrom"] = main.date.SelectedDate.Value.ToShortDateString();
                    checkDT.Rows[0]["dateTo"] = main.dateTo.SelectedDate.Value.ToShortDateString();

                    SqlCommandBuilder checkCB = new SqlCommandBuilder(checkDA);
                    checkDA.Update(checkDT);
                }

                main.price.IsEnabled = true;

                this.Close();
                trans.Close();
                pr.Close();

                con.Close();
            }
        }

        private void name_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            transID = name.SelectedIndex + 1;
            OK.IsEnabled = true;

            SqlDataAdapter da = new SqlDataAdapter("select * from ships", con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i]["name"].ToString().Replace(Environment.NewLine, string.Empty) == name.SelectedValue.ToString())
                {
                    type.Text = dt.Rows[i]["type"].ToString();
                    year.Text = dt.Rows[i]["year"].ToString();
                    length.Text = dt.Rows[i]["length"].ToString();
                    width.Text = dt.Rows[i]["width"].ToString();
                    equipment.Text= dt.Rows[i]["curbWeight"].ToString();
                    maxDraft.Text = dt.Rows[i]["maxDraft"].ToString();
                    maxWeight.Text = dt.Rows[i]["maxWeight"].ToString();
                    flag.Text = dt.Rows[i]["flag"].ToString();
                }
            }
        }


    }
}
