﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace peregrusochnie
{
 
    public partial class chekPrixe : Window
    {
        MainWindow main;
        string connectionString;

        public chekPrixe(MainWindow main, string connectionString)
        {
            InitializeComponent();

            this.main = main;
            this.connectionString = connectionString;

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();

            SqlDataAdapter da = new SqlDataAdapter("select * from  application where id=" + main.appID, con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            agent.Text = dt.Rows[0]["agentPrise"].ToString();
            store.Text = dt.Rows[0]["warePrise"].ToString();
            service.Text = dt.Rows[0]["custPrise"].ToString();
            total.Text = (Convert.ToDouble(agent.Text) + Convert.ToDouble(store.Text) + Convert.ToDouble(service.Text)).ToString();
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            main.IsEnabled = true;
        }
    }
}
