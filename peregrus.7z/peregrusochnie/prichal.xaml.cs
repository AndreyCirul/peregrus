﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace peregrusochnie
{
    public partial class prichal : Window
    {
        MainWindow main;
        string connectionString;
        string id;

        public prichal(MainWindow main, string connectionString, string id, bool enable)
        {
            InitializeComponent();

            this.main = main;
            this.connectionString = connectionString;
            this.id = id;

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();

            this.Title += id;

            if (enable)
            {
                choose.IsEnabled = true;
            }

            SqlDataAdapter da = new SqlDataAdapter("select * from berthes where \"№\"="+id, con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            number.Text = dt.Rows[0]["№"].ToString();
            term.Text = dt.Rows[0]["term"].ToString();
            type.Text = dt.Rows[0]["cargo type"].ToString();
            sort.Text = dt.Rows[0]["cargo sort"].ToString();
            length.Text = dt.Rows[0]["lengthOfBerth"].ToString();
            draw.Text = dt.Rows[0]["berthDepth"].ToString();
            termSize.Text = dt.Rows[0]["terminalCapacity"].ToString();
            equpment.Text = dt.Rows[0]["avaibleEquipment"].ToString();
            weight.Text = dt.Rows[0]["avaibleWeight"].ToString();
            open.Text = dt.Rows[0]["indoorWarehouse"].ToString();
            close.Text = dt.Rows[0]["outdoorWarehouse"].ToString();
            extra.Text = dt.Rows[0]["extra"].ToString();

            con.Close();

            this.SizeToContent = SizeToContent.Height;
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            main.IsEnabled = true;
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void choose_Click(object sender, RoutedEventArgs e)
        {
            chooseTransport tr = new chooseTransport(this, main, connectionString, Convert.ToInt32(id));
            tr.Show();
            this.Hide();
        }
    }
}
