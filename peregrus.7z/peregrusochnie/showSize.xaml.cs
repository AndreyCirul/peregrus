﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace peregrusochnie
{
    /// <summary>
    /// Логика взаимодействия для showSize.xaml
    /// </summary>
    public partial class showSize : Window
    {
        MainWindow main;

        public showSize(MainWindow main)
        {
            InitializeComponent();

            this.main = main;

            weight.Content = main.tonns.ToString() +" тонн";
            if (main.cargoType.SelectedValue.ToString()== "Контейнер")
            {
                size.Content = main.size.ToString() + " TEU";
            }
            else
            {
                size.Content = main.size.ToString() + " метров кубических";
            }

        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            main.IsEnabled = true;
        }
    }
}
