﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace peregrusochnie
{
    public partial class autorisation : Window
    {

        private const string initVector = "pemgail9uzpgzl88";
        private const int keysize = 256;
        private string encriptPass = "P@$$w0rd";
        string connectionString;
        MainWindow main;


        public autorisation(MainWindow main, string connectionString)
        {
            InitializeComponent();

            this.main = main;
            this.connectionString = connectionString;
        }

        public static string EncryptString(string plainText, string passPhrase)
        {
            byte[] initVectorBytes = Encoding.UTF8.GetBytes(initVector);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] cipherTextBytes = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(cipherTextBytes);
        }

        private void log_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter da;
            SqlDataAdapter daWorkers;
            DataTable usersDT = new DataTable();
            DataTable workersDT = new DataTable();

            con.Open();
            da = new SqlDataAdapter("select * from cargoOwners", con);
            da.Fill(usersDT);

            daWorkers = new SqlDataAdapter("select * from workers", con);
            daWorkers.Fill(workersDT);

            bool enter = false;


            for (int i = 0; i < usersDT.Rows.Count; i++)
            {
                if (EncryptString(login.Text, encriptPass) == usersDT.Rows[i][1].ToString() && EncryptString(password.Text, encriptPass) == usersDT.Rows[i][2].ToString())
                {

                    main.userID = Convert.ToInt32(usersDT.Rows[i]["id"]);
                    main.IsEnabled = true;
                    enter = true;
                    main.userTypeChanged("cargoOwner");
                }
            }

            for (int i = 0; i < workersDT.Rows.Count; i++)
            {
                if (EncryptString(login.Text, encriptPass) == workersDT.Rows[i][1].ToString() && EncryptString(password.Text, encriptPass) == workersDT.Rows[i][2].ToString())
                {

                    main.userID = Convert.ToInt32(workersDT.Rows[i][0]);
                    main.IsEnabled = true;
                    enter = true;
                    if (EncryptString("agent", encriptPass) == workersDT.Rows[i]["type"].ToString())
                        main.userTypeChanged("agent");
                    if (EncryptString("warehousingSevise", encriptPass) == workersDT.Rows[i]["type"].ToString())
                        main.userTypeChanged("warehousingSevise");
                    if (EncryptString("customerService", encriptPass) == workersDT.Rows[i]["type"].ToString())
                        main.userTypeChanged("customerService");
                   
                }

            }

            if (!enter)
            {
                if (login.Text == null || login.Text == "" || password.Text == null || password.Text == "")
                    MessageBox.Show("Поля не заполнены");
                else
                    MessageBox.Show("Логин или пароль введены неправильно");
            }
            else
            {
                this.Close();
            }

            con.Close();
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();   
        }

        private void autarisation_Closed(object sender, EventArgs e)
        {
            if (main.userType!="agent")
                main.IsEnabled = true;
        }
    }
}
