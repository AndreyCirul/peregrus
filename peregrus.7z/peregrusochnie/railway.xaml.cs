﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace peregrusochnie
{

    public partial class railway : Window
    {
        chooseTransport trans;
        prichal pr;
        MainWindow main;
        string connectionString;
        int number;
        int transID;

        public railway(chooseTransport trans, prichal pr, MainWindow main, string connectionString, int number)
        {
            InitializeComponent();

            this.trans = trans;
            this.pr = pr;
            this.main = main;
            this.connectionString = connectionString;
            this.number = number;

            switch (main.cargoType.SelectedValue.ToString())
            {
                case "Контейнер":
                    carriage.Items.Add("Крытый вагон");
                    carriage.Items.Add("Рефрижератор");
                    carriage.Items.Add("Платформа");
                    count.IsEnabled = true;
                    break;
                case "Зерно":
                    carriage.Items.Add("Крытый вагон");
                    carriage.Items.Add("Рефрижератор");
                    carriage.Items.Add("Хоппер");
                    break;
                case "Металл":
                    carriage.Items.Add("Крытый вагон");
                    carriage.Items.Add("Рефрижератор");
                    carriage.Items.Add("Платформа");
                    break;
                case "Сыпучий ":
                    carriage.Items.Add("Крытый вагон");
                    carriage.Items.Add("Рефрижератор");
                    carriage.Items.Add("Полувагон");
                    break;
                case "Нефтепродукты":
                    carriage.Items.Add("Крытый вагон");
                    carriage.Items.Add("Рефрижератор");
                    carriage.Items.Add("Цистерна");
                    break;
                case "Газ":
                    carriage.Items.Add("Крытый вагон");
                    carriage.Items.Add("Рефрижератор");
                    carriage.Items.Add("Цистерна");
                    break;
                case "Лес":
                    carriage.Items.Add("Крытый вагон");
                    carriage.Items.Add("Рефрижератор");
                    carriage.Items.Add("Платформа");
                    break;
                case "Наливной":
                    carriage.Items.Add("Крытый вагон");
                    carriage.Items.Add("Рефрижератор");
                    carriage.Items.Add("Цистерна");
                    break;
                case "Тарно-штучный груз":
                    carriage.Items.Add("Крытый вагон");
                    carriage.Items.Add("Рефрижератор");
                    carriage.Items.Add("Платформа");
                    break;
                case "Крытый грузы":
                    carriage.Items.Add("Крытый вагон");
                    carriage.Items.Add("Рефрижератор");
                    carriage.Items.Add("Платформа");
                    break;
                case "Универсальный":
                    carriage.Items.Add("Крытый вагон");
                    carriage.Items.Add("Рефрижератор");
                    carriage.Items.Add("Платформа");
                    break;
            }

        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            trans.Show();
        }

        private void carriage_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            count.IsEnabled = true;

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();


            SqlDataAdapter da = new SqlDataAdapter("select * from railwayCarriage", con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i]["wagonType"].ToString().Replace(Environment.NewLine, string.Empty) == carriage.SelectedValue.ToString())
                {
                    transID = Convert.ToInt32(dt.Rows[i]["Id"]);

                    length.Text = dt.Rows[i]["length"].ToString();
                    width.Text = dt.Rows[i]["width"].ToString();
                    hieght.Text = dt.Rows[i]["height"].ToString();
                    weight.Text = dt.Rows[i]["tonnage"].ToString();
                    type.Text = dt.Rows[i]["type"].ToString();
                    cargoType.Text = dt.Rows[i]["cargoType"].ToString();
                    countCarriage.Text = dt.Rows[i]["count"].ToString();
                }

            }

            SqlDataAdapter usedDA = new SqlDataAdapter("select count from usedTransport where transportType='railway' and ownerId =" + main.appID.ToString() + " and transportId=" + dt.Rows[0]["id"] + " and ((dateFrom>='" + main.date.SelectedDate.Value.ToShortDateString() + "' and dateFrom<='" + main.dateTo.SelectedDate.Value.ToShortDateString() + "') or (dateTo>='" + main.date.SelectedDate.Value.ToShortDateString() + "' and dateTo<='" + main.dateTo.SelectedDate.Value.ToShortDateString() + "'))", con);
            DataTable usedDT = new DataTable();        
            usedDA.Fill(usedDT);
            int getFree = Convert.ToInt32(countCarriage.Text);
            for (int i = 0; i < usedDT.Rows.Count; i++)
            {
                getFree -= Convert.ToInt32(usedDT.Rows[i][0]);
            }
            free.Text = getFree.ToString();
            con.Close();
        }

        private void count_KeyUp(object sender, KeyEventArgs e)
        {
            if (count.Text != "")
            {
                try
                {
                    if (Convert.ToUInt32(count.Text) <= 0)
                    {
                        OK.IsEnabled = false;
                        time.Text = "";
                    }
                    else
                    {
                        if (Convert.ToUInt32(count.Text) > Convert.ToUInt32(free.Text))
                        {
                            count.Text = free.Text;
                        }
                        time.Text = (main.tonns / (Convert.ToUInt32(weight.Text) * Convert.ToUInt32(count.Text))).ToString() + " часов";
                        OK.IsEnabled = true;
                    }

                }
                catch
                {
                    count.Text = "";
                    time.Text = "";
                }
            }
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            if (carriage.SelectedIndex != -1)
            {
                if (Convert.ToInt32(count.Text) > 0)
                {
                    SqlConnection con = new SqlConnection(connectionString);
                    con.Open();

                    SqlDataAdapter da = new SqlDataAdapter("select * from application where id=" + main.appID.ToString(), con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dt.Rows[0]["agentId"] = main.userID;
                    dt.Rows[0]["timeTo"] = (Convert.ToInt32(main.time.Text.Split(':')[0]) + Convert.ToUInt32(time.Text.Split(' ')[0])).ToString() + ":" + main.time.Text.Split(':')[1];
                    dt.Rows[0]["pier"] = number;
                    dt.Rows[0]["usePlatform"] = trans.platform.IsChecked;
                    if (dt.Rows[0]["agentPrise"].ToString() != "")
                    {
                        dt.Rows[0]["status"] = "Ожидает проверки от служб";
                    }

                    if (trans.use.IsChecked == true)
                    {
                        if (trans.close.IsChecked == true)
                        {
                            dt.Rows[0]["storageType"] = "close";
                        }
                        else
                        {
                            dt.Rows[0]["storageType"] = "open";
                        }
                    }
                    else
                    {
                        dt.Rows[0]["storageType"] = "no";
                    }


                    SqlCommandBuilder cb = new SqlCommandBuilder(da);
                    da.Update(dt);

                    SqlDataAdapter checkDA = new SqlDataAdapter("select * from usedTransport where ownerId=" + main.appID.ToString(), con);
                    DataTable checkDT = new DataTable();
                    checkDA.Fill(checkDT);

                    if (checkDT.Rows.Count == 0)
                    {
                        SqlDataAdapter transDA = new SqlDataAdapter("select * from usedTransport", con);
                        DataTable transDT = new DataTable();
                        transDA.Fill(transDT);

                        int newID = 0;
                        for (int i = 0; i < transDT.Rows.Count; i++)
                        {
                            if ((i + 1).ToString() != transDT.Rows[i][0].ToString())
                            {
                                newID = i + 1;
                                break;
                            }
                        }

                        if (newID == 0)
                        {
                            transDT.Rows.Add(transDT.Rows.Count + 1, "railway", transID, count.Text, main.appID, main.date.SelectedDate.Value.ToShortDateString(), main.dateTo.SelectedDate.Value.ToShortDateString());
                        }
                        else
                        {
                            transDT.Rows.Add(newID, "railway", transID, count.Text, main.appID, main.date.SelectedDate.Value.ToShortDateString(), main.dateTo.SelectedDate.Value.ToShortDateString());
                        }

                        SqlCommandBuilder transCB = new SqlCommandBuilder(transDA);
                        transDA.Update(transDT);
                    }
                    else
                    {
                        checkDT.Rows[0]["transportType"] = "railway";
                        checkDT.Rows[0]["transportId"] = transID;
                        checkDT.Rows[0]["count"] = count.Text;
                        checkDT.Rows[0]["dateFrom"] = main.date.SelectedDate.Value.ToShortDateString();
                        checkDT.Rows[0]["dateTo"] = main.dateTo.SelectedDate.Value.ToShortDateString();
                        checkDT.Rows[0]["usePlatform"] = trans.platform.IsChecked;

                        SqlCommandBuilder checkCB = new SqlCommandBuilder(checkDA);
                        checkDA.Update(checkDT);
                    }

                    main.price.IsEnabled = true;

                    this.Close();
                    trans.Close();
                    pr.Close();

                    con.Close();
                }
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            trans.Show();
        }
    }
}
