﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace peregrusochnie
{

    public partial class servisePrice : Window
    {
        MainWindow main;
        string connectionString;
        SqlConnection con;
        SqlDataAdapter da;
        DataTable dt = new DataTable();

        public servisePrice(MainWindow main, string connectionString)
        {
            InitializeComponent();

            this.main = main;
            this.connectionString = connectionString;

            con = new SqlConnection(connectionString);
            con.Open();

            if(main.appID!=0)
            {
                da = new SqlDataAdapter("select * from  application where id=" + main.appID, con);
                da.Fill(dt);

                type.Text = dt.Rows[0]["cargoType"].ToString();
                weight.Text = dt.Rows[0]["cargoWieght"].ToString();
                servise.Text = dt.Rows[0]["servises"].ToString();

                SqlDataAdapter usedTrDA = new SqlDataAdapter("select * from usedTransport where ownerId="+main.appID.ToString(), con);
                DataTable usedTrDT = new DataTable();
                usedTrDA.Fill(usedTrDT);

                switch (usedTrDT.Rows[0]["transportType"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", ""))
                {
                    case "auto":
                        trType.Text = "Автомобиль";
                        CoORN.Content = "Количество:";

                        SqlDataAdapter autoDA = new SqlDataAdapter("select * from auto where id=" + usedTrDT.Rows[0]["transportId"].ToString(), con);
                        DataTable autoDT = new DataTable();
                        autoDA.Fill(autoDT);

                        transportType.Text = autoDT.Rows[0]["autoType"].ToString();
                        countOrName.Text = usedTrDT.Rows[0]["count"].ToString();

                        break;
                    case "reailway":
                        trType.Text = "ЖД";
                        CoORN.Content = "Количество:";

                        SqlDataAdapter railDA = new SqlDataAdapter("select * from railwayCarriage where id=" + usedTrDT.Rows[0]["transportId"].ToString(), con);
                        DataTable railDT = new DataTable();
                        railDA.Fill(railDT);

                        transportType.Text = railDT.Rows[0]["wagonType"].ToString();
                        countOrName.Text = usedTrDT.Rows[0]["count"].ToString();

                        break;
                    case "ship":
                        trType.Text = "Корабль";
                        CoORN.Content = "Имя:";

                        SqlDataAdapter shipDA = new SqlDataAdapter("select * from ships where id=" + usedTrDT.Rows[0]["transportId"].ToString(), con);
                        DataTable shipDT = new DataTable();
                        shipDA.Fill(shipDT);

                        transportType.Text = shipDT.Rows[0]["type"].ToString();
                        countOrName.Text = shipDT.Rows[0]["name"].ToString();
                        break;
                }

                switch(type.Text)
                {
                    case "Контейнер":
                        perPrice.Text= (Convert.ToDouble(dt.Rows[0]["cargoSize"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", ""))*255).ToString();
                        break;
                    case "Зерно":
                        if(Convert.ToBoolean(dt.Rows[0]["usePlatform"]))
                        {
                            perPrice.Text = (Convert.ToDouble(dt.Rows[0]["cargoSize"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "")) * 6.5 + Convert.ToDouble(dt.Rows[0]["cargoSize"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "")) * 5.2).ToString();
                        }
                        else
                            perPrice.Text = (Convert.ToDouble(dt.Rows[0]["cargoSize"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "")) * 6.5).ToString();
                        break;
                    case "Металл":
                        if (Convert.ToBoolean(dt.Rows[0]["usePlatform"]))
                        {
                            perPrice.Text = (Convert.ToDouble(dt.Rows[0]["cargoSize"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "")) * 17 + Convert.ToDouble(dt.Rows[0]["cargoSize"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "")) * 9).ToString();
                        }
                        else
                            perPrice.Text = (Convert.ToDouble(dt.Rows[0]["cargoSize"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "")) * 17).ToString();
                        break;
                    case "Сыпучий ":
                        if (Convert.ToBoolean(dt.Rows[0]["usePlatform"]))
                        {
                            perPrice.Text = (Convert.ToDouble(dt.Rows[0]["cargoSize"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "")) * 6.5 + Convert.ToDouble(dt.Rows[0]["cargoSize"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "")) * 5.2).ToString();
                        }
                        else
                            perPrice.Text = (Convert.ToDouble(dt.Rows[0]["cargoSize"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "")) * 6.5).ToString();
                        break;
                    case "Нефтепродукты":
                        perPrice.Text = (Convert.ToDouble(dt.Rows[0]["cargoSize"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "")) * 7).ToString();
                        break;
                    case "Газ":
                        perPrice.Text = (Convert.ToDouble(dt.Rows[0]["cargoSize"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "")) * 5.9).ToString();
                        break;
                    case "Лес":
                        perPrice.Text = (Convert.ToDouble(dt.Rows[0]["cargoSize"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "")) * 27).ToString();
                        break;
                }                
            }
            else
            {
                OK.IsEnabled = false;
            }
            con.Close();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            main.IsEnabled = true;
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            dt.Rows[0]["custPrise"] = Convert.ToDouble(perPrice.Text) + Convert.ToDouble(transPrice.Text) + Convert.ToDouble(servPrice.Text);
            dt.Rows[0]["custId"] = main.userID;

            if (dt.Rows[0]["warePrise"].ToString() != "")
            {
                dt.Rows[0]["status"] = "Готово";
            }

            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(dt);

            this.Close();

        }
    }
}
