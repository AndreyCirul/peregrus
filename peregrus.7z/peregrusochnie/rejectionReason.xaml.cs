﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;


namespace peregrusochnie
{

    public partial class rejectionReason : Window
    {
        MainWindow main;

        public rejectionReason(MainWindow main, string connectionString, string id)
        {
            InitializeComponent();

            this.main = main;

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();

            SqlDataAdapter da = new SqlDataAdapter("select renouncement from application where id="+id, con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            text.Text = dt.Rows[0][0].ToString();

            con.Close();

            this.SizeToContent = SizeToContent.Height;
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            main.IsEnabled = true;
        }
    }
}
