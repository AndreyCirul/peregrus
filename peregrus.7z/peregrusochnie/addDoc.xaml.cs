﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Drawing;

namespace peregrusochnie
{

    public partial class addDoc : Window
    {
        MainWindow main;

        public addDoc(MainWindow main)
        {
            InitializeComponent();

            this.main = main;
        }

        private void selectPath_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "JPEG Files (*.jpeg)|*.jpeg| JPG Files (*.jpg)|*.jpg";
            dialog.Title = "Выбирите Файл документа";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                path.Text = dialog.FileName;
            }
        }



        private void Window_Closed(object sender, EventArgs e)
        {
            main.IsEnabled = true;
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            if (path.Text != null && path.Text != "")
            {
                main.docImage = Image.FromFile(path.Text);
                this.Close();
            }
            else
            {
                System.Windows.MessageBox.Show("Файл не указан");
            }

        }
    }
}
