﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace peregrusochnie
{

    public partial class servises : Window
    {
        MainWindow main;
        string connectionString;

        public servises(MainWindow main, string connectionString)
        {
            InitializeComponent();

            this.main = main;
            this.connectionString = connectionString;
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            string servises = "";
            
            if(ice.IsChecked==true)
            {
                servises += ice.Content;
            }
            if(clear.IsChecked==true)
            {
                if(servises!="")
                {
                    servises += ", ";
                }
                servises += clear.Content;
            }
            if (mark.IsChecked == true)
            {
                if (servises != "")
                {
                    servises += ", ";
                }
                servises += mark.Content;
            }

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();

            SqlDataAdapter da = new SqlDataAdapter("select * from application where id =" + main.appID.ToString(), con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dt.Rows[0]["agentId"] = main.userID;
            dt.Rows[0]["servises"] = servises;

            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(dt);

            con.Close();

            this.Close();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            main.IsEnabled = true;
        }
    }
}
