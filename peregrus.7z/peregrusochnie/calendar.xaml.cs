﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.IO;

namespace peregrusochnie
{

    public partial class calendar : Window
    {

        private const string initVector = "pemgail9uzpgzl88";
        private const int keysize = 256;
        private string encriptPass = "P@$$w0rd";
        MainWindow main;
        string connectionString;
        DataTable loadCalendarDT = new DataTable();
        DataTable unloadCalendarDT = new DataTable();
        List<int> loadIDs = new List<int>();
        List<int> unloadIDs = new List<int>();


        public calendar(MainWindow main, string connectionString)
        {
            InitializeComponent();

            this.main = main;
            this.connectionString = connectionString;

            loadCalendarDT.Columns.Add("Имя", typeof(string));
            loadCalendarDT.Columns.Add("Дата", typeof(string));
            loadCalendarDT.Columns.Add("Время", typeof(string));
            loadCalendarDT.Columns.Add("Статус", typeof(string));

            load.ItemsSource = loadCalendarDT.DefaultView;

            unloadCalendarDT.Columns.Add("Имя", typeof(string));
            unloadCalendarDT.Columns.Add("Дата", typeof(string));
            unloadCalendarDT.Columns.Add("Время", typeof(string));
            unloadCalendarDT.Columns.Add("Статус", typeof(string));

            unload.ItemsSource = unloadCalendarDT.DefaultView;

            SqlConnection con = new SqlConnection(connectionString);

            con.Open();

            SqlDataAdapter appDA = new SqlDataAdapter("select id, ownerId, agentId, Date, time, status, mode from application order by Date", con);
            DataTable appDT = new DataTable();
            appDA.Fill(appDT);

            for (int i = 0; i < appDT.Rows.Count; i++)
            {

                if (((appDT.Rows[i]["agentId"] == null || appDT.Rows[i]["agentId"].ToString() == "" || appDT.Rows[i]["agentId"].ToString()=="0") || appDT.Rows[i]["agentId"].ToString() == main.userID.ToString()) && appDT.Rows[i]["status"].ToString() == "Ожидает проверки судового агента")
                {
                   

                    if (appDT.Rows[i]["mode"].ToString() == "Погрузка")
                    {
                        

                        SqlDataAdapter usersDA = new SqlDataAdapter("select login from cargoOwners where id=" + appDT.Rows[i]["ownerId"].ToString(), con);
                        DataTable usersDT = new DataTable();
                        usersDA.Fill(usersDT);
                        
                        loadCalendarDT.Rows.Add(DecryptString(usersDT.Rows[0][0].ToString(), encriptPass), Convert.ToDateTime(appDT.Rows[i]["Date"]).ToShortDateString(), appDT.Rows[i]["time"], appDT.Rows[i]["status"]);         
                        loadIDs.Add(Convert.ToInt32(appDT.Rows[i]["id"])); 
                    }
                    else
                    {
                        
                        SqlDataAdapter usersDA = new SqlDataAdapter("select login from cargoOwners where id=" + appDT.Rows[i]["ownerId"].ToString(), con);
                        DataTable usersDT = new DataTable();
                        usersDA.Fill(usersDT);
                       
                        unloadCalendarDT.Rows.Add(DecryptString(usersDT.Rows[0][0].ToString(), encriptPass), Convert.ToDateTime(appDT.Rows[i]["Date"]).ToShortDateString(), appDT.Rows[i]["time"], appDT.Rows[i]["status"]);
                      
                        unloadIDs.Add(Convert.ToInt32(appDT.Rows[i]["id"]));
                       
                    }
                }
            }

            con.Close();

        }

        public static string DecryptString(string cipherText, string passPhrase)
        {
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] cipherTextBytes = Convert.FromBase64String(cipherText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform decryptor = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream(cipherTextBytes);
            CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
            byte[] plainTextBytes = new byte[cipherTextBytes.Length];
            int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
            memoryStream.Close();
            cryptoStream.Close();
            return Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);
        }

        private void Window_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            int b = load.Columns.Count;
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            main.IsEnabled = true;
        }

        private void loadOK_Click(object sender, RoutedEventArgs e)
        {
            if (load.SelectedIndex != -1)
            {
                main.open_app(loadIDs[load.SelectedIndex]);
                main.renouncement.IsEnabled = true;
                this.Close();

                main.terminals.Visibility = Visibility.Visible;
                main.terminal1.Visibility = Visibility.Hidden;
                main.terminal2.Visibility = Visibility.Hidden;
                main.terminal3.Visibility = Visibility.Hidden;
                main.terminal4.Visibility = Visibility.Hidden;
                main.terminal5.Visibility = Visibility.Hidden;
                main.terminal6.Visibility = Visibility.Hidden;
                main.terminal7.Visibility = Visibility.Hidden;
                main.terminal8.Visibility = Visibility.Hidden;

                main.bTerm1.Background = main.ok.Background;
                main.bTerm2.Background = main.ok.Background;
                main.bTerm3.Background = main.ok.Background;
                main.bTerm4.Background = main.ok.Background;
                main.bTerm5.Background = main.ok.Background;
                main.bTerm6.Background = main.ok.Background;
                main.bTerm7.Background = main.ok.Background;
                main.bTerm8.Background = main.ok.Background;

                for (int i = 0; i < main.term1.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid1.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term1.Rows[i][1] = "";
                }

                for (int i = 0; i < main.term2.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid2.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term2.Rows[i][1] = "";
                }

                for (int i = 0; i < main.term3.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid3.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term3.Rows[i][1] = "";
                }

                for (int i = 0; i < main.term4.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid4.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term4.Rows[i][1] = "";
                }

                for (int i = 0; i < main.term5.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid5.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term5.Rows[i][1] = "";
                }

                for (int i = 0; i < main.term6.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid6.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term6.Rows[i][1] = "";
                }

                for (int i = 0; i < main.term7.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid7.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term7.Rows[i][1] = "";
                }

                for (int i = 0; i < main.term8.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid8.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term8.Rows[i][1] = "";
                }
            }
        }

        private void unloadOK_Click(object sender, RoutedEventArgs e)
        {
            if (unload.SelectedIndex != -1)
            {
                main.open_app(unloadIDs[unload.SelectedIndex]);
                main.renouncement.IsEnabled = true;
                this.Close();

                main.terminals.Visibility = Visibility.Visible;
                main.terminal1.Visibility = Visibility.Hidden;
                main.terminal2.Visibility = Visibility.Hidden;
                main.terminal3.Visibility = Visibility.Hidden;
                main.terminal4.Visibility = Visibility.Hidden;
                main.terminal5.Visibility = Visibility.Hidden;
                main.terminal6.Visibility = Visibility.Hidden;
                main.terminal7.Visibility = Visibility.Hidden;
                main.terminal8.Visibility = Visibility.Hidden;

                main.bTerm1.Background = main.ok.Background;
                main.bTerm2.Background = main.ok.Background;
                main.bTerm3.Background = main.ok.Background;
                main.bTerm4.Background = main.ok.Background;
                main.bTerm5.Background = main.ok.Background;
                main.bTerm6.Background = main.ok.Background;
                main.bTerm7.Background = main.ok.Background;
                main.bTerm8.Background = main.ok.Background;

                for (int i = 0; i < main.term1.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid1.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term1.Rows[i][1] = "";
                }

                for (int i = 0; i < main.term2.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid2.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term2.Rows[i][1] = "";
                }

                for (int i = 0; i < main.term3.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid3.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term3.Rows[i][1] = "";
                }

                for (int i = 0; i < main.term4.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid4.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term4.Rows[i][1] = "";
                }

                for (int i = 0; i < main.term5.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid5.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term5.Rows[i][1] = "";
                }

                for (int i = 0; i < main.term6.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid6.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term6.Rows[i][1] = "";
                }

                for (int i = 0; i < main.term7.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid7.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term7.Rows[i][1] = "";
                }

                for (int i = 0; i < main.term8.Rows.Count; i++)
                {
                    DataGridRow row = (DataGridRow)main.pirsesGrid8.ItemContainerGenerator.ContainerFromIndex(i);
                    row.Background = Brushes.White;
                    main.term8.Rows[i][1] = "";
                }
            }
        }

        private void loadBack_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void unloadBack_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
