﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace peregrusochnie
{

    public partial class Refuse : Window
    {
        MainWindow main;
        string connectionString;

        public Refuse(MainWindow main, string connectionString)
        {
            InitializeComponent();

            this.main = main;
            this.connectionString = connectionString;
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            main.IsEnabled = true;

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();

            SqlDataAdapter da = new SqlDataAdapter("select * from application", con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            for (int i=0; i<dt.Rows.Count; i++)
            {
                if (dt.Rows[i]["Id"].ToString()==main.appID.ToString())
                {
                    dt.Rows[i]["agentID"] = 0;
                    dt.Rows[i]["status"] = "Отказано";
                    dt.Rows[i]["renouncement"] = text.Text;
                }
            }

            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(dt);

            main.userTypeChanged("no");

            con.Close();
        }
    }
}
