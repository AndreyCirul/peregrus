﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace peregrusochnie
{

    public partial class storePrice : Window
    {
        MainWindow main;
        string connectionString;
        SqlConnection con;
        SqlDataAdapter da;
        DataTable dt = new DataTable();


        public storePrice(MainWindow main, string connectionString)
        {
            InitializeComponent();

            this.main = main;
            this.connectionString = connectionString;
            con = new SqlConnection(connectionString);
            con.Open();
            if (main.appID!=0)
                {
                

                da = new SqlDataAdapter("select * from  application where id=" + main.appID, con);
                da.Fill(dt);

                
                pier.Text = dt.Rows[0]["pier"].ToString();
                type.Text = dt.Rows[0]["cargoType"].ToString();
                weight.Text = dt.Rows[0]["cargoWieght"].ToString();
                dateFrom.Text = Convert.ToDateTime(dt.Rows[0]["Date"]).ToShortDateString();
                dateTo.Text = Convert.ToDateTime(dt.Rows[0]["DateTo"]).ToShortDateString();

                SqlDataAdapter prisesDA = new SqlDataAdapter();
                if (dt.Rows[0]["storageType"].ToString() != "no")
                {
                    if (dt.Rows[0]["storageType"].ToString() == "open")
                    {
                        storageType.Text = "Открытый";
                        prisesDA = new SqlDataAdapter("select opened, cargoType from storageCost", con);
                    }
                    if (dt.Rows[0]["storageType"].ToString() == "close")
                    {
                        storageType.Text = "Закрытый";
                        prisesDA = new SqlDataAdapter("select closed, cargoType from storageCost", con);
                    }
                    DataTable prisesDT = new DataTable();
                    prisesDA.Fill(prisesDT);

                    int a = prisesDT.Rows.Count;

                    for (int i = 0; i < prisesDT.Rows.Count; i++)
                    {
                        if (prisesDT.Rows[i][1].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "") == type.Text)
                        {
                            price.Text = (Convert.ToDateTime(dateTo.Text).Subtract(Convert.ToDateTime(dateFrom.Text)).TotalDays * Convert.ToInt32(weight.Text) * Convert.ToDouble(prisesDT.Rows[i][0])).ToString();
                        }
                    }
                }
                else
                {
                    storageType.Text = "Нет";
                    price.Text = "0";
                }
            }
            else
            {
                OK.IsEnabled = false;
            }
            con.Close();
         }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            main.IsEnabled = true;
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            dt.Rows[0]["warePrise"] = price.Text;
            dt.Rows[0]["warehId"] = main.userID;

            if (dt.Rows[0]["custPrise"].ToString()!="")
            {
                dt.Rows[0]["status"] = "Готово";
            }

            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(dt);

            this.Close();
        }
    }
}
