﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace peregrusochnie
{

    public partial class MainWindow : Window
    {

        public System.Drawing.Image docImage;
        public double size = 0;
        public int tonns = 0;
        public int userID = 0;
        public int appID = 0;
        public int agentPrice = 0;
        public string userType = "no";
        static string connectionString;
        SqlConnection con;
        List<MenuItem> menuItems = new List<MenuItem>();
        public DataTable term1 = new DataTable();
        public DataTable term2 = new DataTable();
        public DataTable term3 = new DataTable();
        public DataTable term4 = new DataTable();
        public DataTable term5 = new DataTable();
        public DataTable term6 = new DataTable();
        public DataTable term7 = new DataTable();
        public DataTable term8 = new DataTable();
        public DataTable pirsDT = new DataTable();


        public MainWindow()
        {
            InitializeComponent();

            StreamReader sr = new StreamReader("serverName.txt");
            string serverName = sr.ReadLine();
            connectionString = "Data Source=" + serverName + ";Initial Catalog=peregruskaBD;Integrated Security=True";

            con = new SqlConnection(connectionString);

            con.Open();
           
            SqlDataAdapter daShips = new SqlDataAdapter("select distinct type from ships", con);
            DataTable tdShips = new DataTable();
            daShips.Fill(tdShips);

            for (int i = 0; i < tdShips.Rows.Count; i++)
            {
                string text = tdShips.Rows[i][0].ToString();
                text = text.Replace(Environment.NewLine, string.Empty);
                shipType.Items.Add(text);
            }

            SqlDataAdapter daCargo = new SqlDataAdapter("select cargoType from storageCost", con);
            DataTable tdCargo = new DataTable();
            daCargo.Fill(tdCargo);

            for (int i = 0; i < tdCargo.Rows.Count; i++)
            {
                string text = tdCargo.Rows[i][0].ToString();
                text = text.Replace(Environment.NewLine, string.Empty);
                text = text.Replace(" ", "");
                cargoType.Items.Add(text);
            }
            cargoType.Items.Add("Наливной");
            cargoType.Items.Add("Тарно-штучный груз");
            cargoType.Items.Add("Крытый грузы");
            cargoType.Items.Add("Универсальный");

            SqlDataAdapter daFlag = new SqlDataAdapter("select distinct flag from ships", con);
            DataTable tdFlag = new DataTable();
            daFlag.Fill(tdFlag);

            for (int i = 0; i < tdFlag.Rows.Count; i++)
            {
                string text = tdFlag.Rows[i][0].ToString();
                text = text.Replace(Environment.NewLine, string.Empty);
                flag.Items.Add(text);
            }

            SqlDataAdapter pirsDA = new SqlDataAdapter("select \"№\" from berthes", con);
            pirsDA.Fill(pirsDT);
            pirsDT.Columns.Add("stat");
            pirsDT.Columns.Add("text");

            date.DisplayDateStart = DateTime.Today;

            dateTo.DisplayDateStart = date.DisplayDateStart.Value.AddDays(2);
            con.Close();

            #region fillTerms
            term1.Columns.Add("Номер");
            term1.Columns.Add("Статус");
            pirsesGrid1.ItemsSource = term1.DefaultView;

            term1.Rows.Add("1");
            term1.Rows.Add("2");

            term2.Columns.Add("Номер");
            term2.Columns.Add("Статус");
            pirsesGrid2.ItemsSource = term2.DefaultView;

            term2.Rows.Add("3");
            term2.Rows.Add("4");
            term2.Rows.Add("5");
            term2.Rows.Add("7");
            term2.Rows.Add("8");

            term3.Columns.Add("Номер");
            term3.Columns.Add("Статус");
            pirsesGrid3.ItemsSource = term3.DefaultView;

            term3.Rows.Add("9");
            term3.Rows.Add("10");
            term3.Rows.Add("11");
            term3.Rows.Add("12");
            term3.Rows.Add("13");

            term4.Columns.Add("Номер");
            term4.Columns.Add("Статус");
            pirsesGrid4.ItemsSource = term4.DefaultView;

            term4.Rows.Add("14");

            term5.Columns.Add("Номер");
            term5.Columns.Add("Статус");
            pirsesGrid5.ItemsSource = term5.DefaultView;

            term5.Rows.Add("15");

            term6.Columns.Add("Номер");
            term6.Columns.Add("Статус");
            pirsesGrid6.ItemsSource = term6.DefaultView;

            term6.Rows.Add("21");
            term6.Rows.Add("23");
            term6.Rows.Add("24");
            term6.Rows.Add("25");
            term6.Rows.Add("26");

            term7.Columns.Add("Номер");
            term7.Columns.Add("Статус");
            pirsesGrid7.ItemsSource = term7.DefaultView;

            term7.Rows.Add("29");
            term7.Rows.Add("30");
            term7.Rows.Add("31");
            term7.Rows.Add("32");
            term7.Rows.Add("33");

            term8.Columns.Add("Номер");
            term8.Columns.Add("Статус");
            pirsesGrid8.ItemsSource = term8.DefaultView;

            term8.Rows.Add("38");
            term8.Rows.Add("42");
            term8.Rows.Add("43");
            term8.Rows.Add("44");
            term8.Rows.Add("45");
            term8.Rows.Add("46");
            term8.Rows.Add("47");
            #endregion


        }

        public void userTypeChanged(string newType)
        {
            switch (newType)
            {
                case "no":
                    #region no
                    terminals.IsEnabled = false;
                    ship.IsEnabled = false;
                    cargo.IsEnabled = false;
                    ok.IsEnabled = false;
                    price.IsEnabled = true;
                    userType = "no";
                    exit.Visibility = Visibility.Collapsed;
                    Register.Visibility = Visibility.Visible;
                    login.Visibility = Visibility.Visible;
                    _new.Visibility = Visibility.Collapsed;
                    open.Visibility = Visibility.Collapsed;
                    weight.Visibility = Visibility.Collapsed;
                    price.Visibility = Visibility.Collapsed;
                    doc.Visibility = Visibility.Collapsed;
                    servises.Visibility = Visibility.Collapsed;
                    stock.Visibility = Visibility.Collapsed;
                    tehnick.Visibility = Visibility.Collapsed;
                    renouncement.Visibility = Visibility.Collapsed;
                   

                    userID = 0;
                    appID = 0;
                    tonns = 0;
                    size = 0;
                    agentPrice = 0;
                    docImage = null;
                    date.SelectedDate = null;
                    dateTo.SelectedDate = null;
                    time.Text = "";
                    shipOwner.Text = "";
                    width.Text = "";
                    length.Text = "";
                    maxDraft.Text = "";
                    documents.IsChecked = false;
                    shipType.SelectedIndex = -1;
                    cargoType.SelectedIndex = -1;
                    flag.SelectedIndex = -1;

                    open_clear();

                    terminals.Visibility = Visibility.Visible;
                    terminal1.Visibility = Visibility.Hidden;
                    terminal2.Visibility = Visibility.Hidden;
                    terminal3.Visibility = Visibility.Hidden;
                    terminal4.Visibility = Visibility.Hidden;
                    terminal5.Visibility = Visibility.Hidden;
                    terminal6.Visibility = Visibility.Hidden;
                    terminal7.Visibility = Visibility.Hidden;
                    terminal8.Visibility = Visibility.Hidden;

                    bTerm1.Background = ok.Background;
                    bTerm2.Background = ok.Background;
                    bTerm3.Background = ok.Background;
                    bTerm4.Background = ok.Background;
                    bTerm5.Background = ok.Background;
                    bTerm6.Background = ok.Background;
                    bTerm7.Background = ok.Background;
                    bTerm8.Background = ok.Background;

                    for (int i = 0; i < term1.Rows.Count; i++)
                    {
                        DataGridRow row = (DataGridRow)pirsesGrid1.ItemContainerGenerator.ContainerFromIndex(i);
                        row.Background = Brushes.White;
                        term1.Rows[i][1] = "";
                    }

                    for (int i = 0; i < term2.Rows.Count; i++)
                    {
                        DataGridRow row = (DataGridRow)pirsesGrid2.ItemContainerGenerator.ContainerFromIndex(i);
                        row.Background = Brushes.White;
                        term2.Rows[i][1] = "";
                    }

                    for (int i = 0; i < term3.Rows.Count; i++)
                    {
                        DataGridRow row = (DataGridRow)pirsesGrid3.ItemContainerGenerator.ContainerFromIndex(i);
                        row.Background = Brushes.White;
                        term3.Rows[i][1] = "";
                    }

                    for (int i = 0; i < term4.Rows.Count; i++)
                    {
                        DataGridRow row = (DataGridRow)pirsesGrid4.ItemContainerGenerator.ContainerFromIndex(i);
                        row.Background = Brushes.White;
                        term4.Rows[i][1] = "";
                    }

                    for (int i = 0; i < term5.Rows.Count; i++)
                    {
                        DataGridRow row = (DataGridRow)pirsesGrid5.ItemContainerGenerator.ContainerFromIndex(i);
                        row.Background = Brushes.White;
                        term5.Rows[i][1] = "";
                    }

                    for (int i = 0; i < term6.Rows.Count; i++)
                    {
                        DataGridRow row = (DataGridRow)pirsesGrid6.ItemContainerGenerator.ContainerFromIndex(i);
                        row.Background = Brushes.White;
                        term6.Rows[i][1] = "";
                    }

                    for (int i = 0; i < term7.Rows.Count; i++)
                    {
                        DataGridRow row = (DataGridRow)pirsesGrid7.ItemContainerGenerator.ContainerFromIndex(i);
                        row.Background = Brushes.White;
                        term7.Rows[i][1] = "";
                    }

                    for (int i = 0; i < term8.Rows.Count; i++)
                    {
                        DataGridRow row = (DataGridRow)pirsesGrid8.ItemContainerGenerator.ContainerFromIndex(i);
                        row.Background = Brushes.White;
                        term8.Rows[i][1] = "";
                    }

                    #endregion
                    break;
                case "cargoOwner":
                    #region cargoOwner
                    terminals.IsEnabled = false;
                    ship.IsEnabled = true;
                    cargo.IsEnabled = true;
                    ok.IsEnabled = true;
                    rej1.IsEnabled = true;
                    rej2.IsEnabled = true;
                    date.IsEnabled = true;
                    time.IsEnabled = true;
                    shipType.IsEnabled = true;
                    price.IsEnabled = false;
                    cargoType.IsEnabled = true;
                    userType = "cargoOwner";
                    exit.Visibility = Visibility.Visible;
                    Register.Visibility = Visibility.Collapsed;
                    login.Visibility = Visibility.Collapsed;
                    _new.Visibility = Visibility.Visible;
                    open.Visibility = Visibility.Visible;
                    weight.Visibility = Visibility.Visible;
                    weight.Header = "Указать вес груза";
                    price.Visibility = Visibility.Visible;
                    price.Header = "Просмотреть цену";
                    doc.Visibility = Visibility.Visible;
                    doc.Header = "Загрузить документ";
                    servises.Visibility = Visibility.Collapsed;
                    stock.Visibility = Visibility.Collapsed;
                    tehnick.Visibility = Visibility.Collapsed;

                    con.Open();

                    SqlDataAdapter da = new SqlDataAdapter("select * from application where ownerId=" + userID.ToString(), con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (Convert.ToInt32(dt.Rows[i]["id"]) != appID)
                        {
                            MenuItem appOpen = new MenuItem();
                            appOpen.Name = "O" + dt.Rows[i]["id"].ToString();

                            appOpen.Header = dt.Rows[i]["mode"].ToString();
                            if (dt.Rows[i]["Date"].ToString()!="" && dt.Rows[i]["Date"].ToString() != null)
                                appOpen.Header+= " " + Convert.ToDateTime(dt.Rows[i]["Date"]).ToShortDateString();
                            appOpen.Visibility = Visibility.Visible;
                            appOpen.Click += Open_Click;
                            if (dt.Rows[i]["status"].ToString() == "Не заполнено" || dt.Rows[i]["status"].ToString() == "Готово" || dt.Rows[i]["status"].ToString() == "Отказано")
                            {
                                appOpen.Header += " " + dt.Rows[i]["status"].ToString();;
                                if (dt.Rows[i]["status"].ToString() == "Не заполнено")
                                {
                                    appOpen.Background = Brushes.Yellow;
                                }
                                if (dt.Rows[i]["status"].ToString() == "Отказано")
                                {            
                                    appOpen.Background = Brushes.Red;                                   
                                    renouncement.Header = "Причина отказа";
                                }
                            }
                            else
                            {
          
                                appOpen.Header += " Обрабатывается";
                                appOpen.IsEnabled = false;
                            }
                            open.Items.Add(appOpen);
                        }
                    }

                    con.Close();
                    #endregion
                    break;
                case "agent":
                    #region agent
                    terminals.IsEnabled = true;
                    ship.IsEnabled = false;
                    cargo.IsEnabled = false;
                    ok.IsEnabled = true;
                    rej1.IsEnabled = false;
                    rej2.IsEnabled = false;
                    date.IsEnabled = true;
                    time.IsEnabled = true;
                    shipType.IsEnabled = false;
                    cargoType.IsEnabled = false;
                    userType = "agent";
                    exit.Visibility = Visibility.Visible;
                    Register.Visibility = Visibility.Collapsed;
                    login.Visibility = Visibility.Collapsed;
                    _new.Visibility = Visibility.Collapsed;
                    open.Visibility = Visibility.Visible;
                    weight.Visibility = Visibility.Visible;
                    weight.Header = "Просмотреть вес груза";
                    price.Visibility = Visibility.Visible;
                    price.Header = "Указать цену";
                    price.IsEnabled = false;
                    doc.Visibility = Visibility.Visible;
                    doc.Header = "Просмотреть документ";
                    servises.Visibility = Visibility.Visible;
                    stock.Visibility = Visibility.Visible;
                    tehnick.Visibility = Visibility.Visible;
                    renouncement.Visibility = Visibility.Visible;
                    renouncement.Header = "Отказать";


                    calendar cal = new calendar(this, connectionString);
                    cal.Show();
                    this.IsEnabled = false;
                    #endregion
                    break;
                case "warehousingSevise":
                    #region warehousingSevise
                    terminals.IsEnabled = true;
                    ship.IsEnabled = false;
                    cargo.IsEnabled = false;
                    ok.IsEnabled = false;
                    rej1.IsEnabled = false;
                    rej2.IsEnabled = false;
                    date.IsEnabled = false;
                    time.IsEnabled = false;
                    shipType.IsEnabled = false;
                    cargoType.IsEnabled = false;
                    userType = "warehousingSevise";
                    exit.Visibility = Visibility.Visible;
                    Register.Visibility = Visibility.Collapsed;
                    login.Visibility = Visibility.Collapsed;
                    _new.Visibility = Visibility.Collapsed;
                    open.Visibility = Visibility.Visible;
                    weight.Visibility = Visibility.Collapsed;
                    price.Visibility = Visibility.Visible;
                    price.Header = "Указать цену";
                    price.IsEnabled = false;
                    doc.Visibility = Visibility.Collapsed;
                    servises.Visibility = Visibility.Collapsed;
                    servises.Header = "Заказать услуги";
                    stock.Visibility = Visibility.Visible;

                    con.Open();

                    SqlDataAdapter warDA = new SqlDataAdapter("select * from application", con);
                    DataTable warDT = new DataTable();
                    warDA.Fill(warDT);

                    for (int i = 0; i < warDT.Rows.Count; i++)
                    {
                        if (Convert.ToInt32(warDT.Rows[i]["id"]) != appID)
                        {
                            if (warDT.Rows[i]["status"].ToString() == "Ожидает проверки от служб" && (warDT.Rows[i]["warehId"] == null || warDT.Rows[i]["warehId"].ToString() == "" ||  Convert.ToUInt32(warDT.Rows[i]["warehId"])==userID))
                            {
                                MenuItem appOpen = new MenuItem();
                                appOpen.Name = "O" + warDT.Rows[i]["id"].ToString();
                                appOpen.Header = warDT.Rows[i]["mode"].ToString() + " " + Convert.ToDateTime(warDT.Rows[i]["Date"]).ToShortDateString();
                                appOpen.Visibility = Visibility.Visible;
                                appOpen.Click += Open_Click;
                                open.Items.Add(appOpen);
                            }
                        }
                    }

                    con.Close();
                    #endregion
                    break;
                case "customerService":
                    #region customerService
                    terminals.IsEnabled = false;
                    ship.IsEnabled = false;
                    cargo.IsEnabled = false;
                    ok.IsEnabled = false;
                    rej1.IsEnabled = false;
                    rej2.IsEnabled = false;
                    date.IsEnabled = false;
                    time.IsEnabled = false;
                    shipType.IsEnabled = false;
                    cargoType.IsEnabled = false;
                    userType = "customerService";
                    exit.Visibility = Visibility.Visible;
                    Register.Visibility = Visibility.Collapsed;
                    login.Visibility = Visibility.Collapsed;
                    _new.Visibility = Visibility.Collapsed;
                    open.Visibility = Visibility.Visible;
                    price.Header = "Указать цену";
                    price.IsEnabled = false;
                    weight.Visibility = Visibility.Collapsed;
                    price.Visibility =Visibility.Visible;
                    doc.Visibility = Visibility.Collapsed;
                    servises.Visibility = Visibility.Collapsed;
                    stock.Visibility = Visibility.Collapsed;
                    tehnick.Visibility = Visibility.Visible;

                    SqlDataAdapter serDA = new SqlDataAdapter("select * from application", con);
                    DataTable serDT = new DataTable();
                    serDA.Fill(serDT);

                    for (int i = 0; i < serDT.Rows.Count; i++)
                    {
                        if (Convert.ToInt32(serDT.Rows[i]["id"]) != appID)
                        {
                            if (serDT.Rows[i]["status"].ToString() == "Ожидает проверки от служб" && (serDT.Rows[i]["custId"].ToString() == "" || Convert.ToUInt32(serDT.Rows[i]["custId"]) == userID))
                            {
                                MenuItem appOpen = new MenuItem();
                                appOpen.Name = "O" + serDT.Rows[i]["id"].ToString();
                                appOpen.Header = serDT.Rows[i]["mode"].ToString() + " " + Convert.ToDateTime(serDT.Rows[i]["Date"]).ToShortDateString();
                                appOpen.Visibility = Visibility.Visible;
                                appOpen.Click += Open_Click;
                                open.Items.Add(appOpen);
                            }
                        }
                    }
                    #endregion
                    break;
            }
        }

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            MenuItem item = sender as MenuItem;
            open_app(Convert.ToInt32(item.Name.Substring(1)));

            if (userType== "warehousingSevise" || userType== "customerService")
            {
                price.IsEnabled = true;
            }
        }

        public void open_app(int id)
        {
            tonns = 0;
            size = 0;
            docImage = null;
            date.SelectedDate = null;
            dateTo.SelectedDate = null;
            time.Text = "";
            shipOwner.Text = "";
            width.Text = "";
            length.Text = "";
            maxDraft.Text = "";
            documents.IsChecked = false;
            shipType.SelectedIndex = -1;
            cargoType.SelectedIndex = -1;
            flag.SelectedIndex = -1;

            con.Open();

            appID = id;

            SqlDataAdapter da = new SqlDataAdapter("select * from application where id=" + id.ToString(), con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows[0]["mode"].ToString() == "Погрузка")
            {
                rej1.IsChecked = true;
            }
            else
            {
                rej2.IsChecked = true;
            }
            if (dt.Rows[0]["Date"].ToString() != "")
            {
                if (Convert.ToDateTime(dt.Rows[0]["Date"]) < DateTime.Today)
                    date.DisplayDateStart = Convert.ToDateTime(dt.Rows[0]["Date"]);
                else
                    date.DisplayDateStart = DateTime.Today;


                date.SelectedDate = Convert.ToDateTime(dt.Rows[0]["Date"]);             
            }
            if (dt.Rows[0]["DateTo"].ToString() != "")
            {
                dateTo.DisplayDateStart = date.DisplayDateStart.Value.AddDays(2);
                dateTo.SelectedDate = Convert.ToDateTime(dt.Rows[0]["DateTo"]);
            }
                time.Text = dt.Rows[0]["time"].ToString();


            for (int j = 0; j < shipType.Items.Count; j++)
            {
                string text = (string)(shipType.Items[j]);
  

                if (text == dt.Rows[0]["shipType"].ToString())
                {
                    shipType.SelectedIndex = j;
                    break;
                }
            }

            shipOwner.Text = dt.Rows[0]["shipOwner"].ToString();

            for (int j = 0; j < flag.Items.Count; j++)
            {
                string text = (string)(flag.Items[j]);
                if (text == dt.Rows[0]["shipFlag"].ToString())
                {
                    flag.SelectedIndex = j;
                    break;
                }
            }

            documents.IsChecked = Convert.ToBoolean(dt.Rows[0]["shipDocuments"]);
            width.Text = dt.Rows[0]["shipWidth"].ToString();
            length.Text = dt.Rows[0]["shipLength"].ToString();
            maxDraft.Text = dt.Rows[0]["shipMaxDraft"].ToString();

            for (int j = 0; j < cargoType.Items.Count; j++)
            {
                string text = (string)(cargoType.Items[j]);

                string text2 = dt.Rows[0]["cargoType"].ToString();
                text2 = text2.Replace(Environment.NewLine, string.Empty);
                if (text2!= "Тарно-штучный груз" && text2 != "Крытый грузы")
                    text2 = text2.Replace(" ", "");

                if (text == text2)
                {
                    cargoType.SelectedIndex = j;
                    break;
                }
            }
            if (dt.Rows[0]["cargoSize"] != null && dt.Rows[0]["cargoSize"].ToString() != "")
                size = Convert.ToDouble(dt.Rows[0]["cargoSize"]);
            if (dt.Rows[0]["cargoWieght"] != null && dt.Rows[0]["cargoWieght"].ToString() != "")
                tonns = Convert.ToInt32(dt.Rows[0]["cargoWieght"]);

            if (dt.Rows[0]["doc"] != null && dt.Rows[0]["doc"].ToString() != "")
            {
                MemoryStream ms = new MemoryStream((byte[])(dt.Rows[0]["doc"]));
                docImage = System.Drawing.Image.FromStream(ms);
            }

            if(dt.Rows[0]["status"].ToString()=="" || dt.Rows[0]["status"].ToString() == "Ожидает проверки от служб" || dt.Rows[0]["status"].ToString() == "Ожидает проверки судового агента")
            {
                if (userType== "cargoOwner")
                    price.IsEnabled = false;
            }

            if (dt.Rows[0]["status"].ToString() == "Готово")
            {
                price.IsEnabled = true;
                ship.IsEnabled = false;
                cargo.IsEnabled = false;
                ok.IsEnabled = false;
            }


            if (dt.Rows[0]["status"].ToString() == "Отказано" || userType == "agent")
            {
                renouncement.Visibility = Visibility.Visible;
                price.IsEnabled = false;
                ship.IsEnabled = true;
                cargo.IsEnabled = true;
                ok.IsEnabled = true;
            }
            else
                renouncement.Visibility = Visibility.Collapsed;

            con.Close();
        }

        private void open_clear()
        {
            for (int i = open.Items.Count - 1; i >= 0; i--)
            {
                open.Items.RemoveAt(i);
            }
        }

        private void ok_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                switch (userType)
                {
                    case "cargoOwner":
                        #region cargoOwner
                        con.Open();


                        SqlDataAdapter daApp = new SqlDataAdapter("select * from application", con);
                        DataTable dtApp = new DataTable();
                        daApp.Fill(dtApp);

                        if (appID == 0)
                        {
                            int newID = 0;
                            for (int i = 0; i < dtApp.Rows.Count; i++)
                            {
                                if ((i + 1).ToString() != dtApp.Rows[i][0].ToString())
                                {
                                    newID = i + 1;
                                    break;
                                }
                            }

                            if (newID == 0)
                            {
                                dtApp.Rows.Add(dtApp.Rows.Count + 1);
                            }
                            else
                            {
                                dtApp.Rows.Add(newID);
                            }


                            appID = dtApp.Rows.Count;
                        }

                        dtApp.Rows[appID - 1]["ownerId"] = userID;
                        if (date.SelectedDate != null)
                            dtApp.Rows[appID - 1]["Date"] = date.SelectedDate.Value.ToShortDateString();
                        if (dateTo.SelectedDate != null)
                            dtApp.Rows[appID - 1]["DateTo"] = dateTo.SelectedDate.Value.ToShortDateString();
                        dtApp.Rows[appID - 1]["time"] = time.Text;
                        if (cargoType.SelectedIndex != -1)
                            dtApp.Rows[appID - 1]["cargoType"] = cargoType.SelectedValue.ToString();
                        if (docImage != null)
                        {
                            MemoryStream ms = new MemoryStream();
                            docImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                            dtApp.Rows[appID - 1]["doc"] = ms.ToArray();
                        }   
                        if (shipType.SelectedIndex != -1)
                            dtApp.Rows[appID - 1]["shipType"] = shipType.SelectedValue.ToString();
                        dtApp.Rows[appID - 1]["shipOwner"] = shipOwner.Text;
                        if (flag.SelectedIndex != -1)
                            dtApp.Rows[appID - 1]["shipFlag"] = flag.SelectedValue.ToString();
                        if (width.Text != null && width.Text != "")
                            dtApp.Rows[appID - 1]["shipWidth"] = Convert.ToDouble(width.Text);
                        if (length.Text != null && width.Text != "")
                            dtApp.Rows[appID - 1]["shipLength"] = Convert.ToDouble(length.Text);
                        if (maxDraft.Text != null && width.Text != "")
                            dtApp.Rows[appID - 1]["shipMaxDraft"] = Convert.ToDouble(maxDraft.Text);
                        dtApp.Rows[appID - 1]["cargoSize"] = size;
                        dtApp.Rows[appID - 1]["cargoWieght"] = tonns;

                        if (date.SelectedDate!=null && dateTo.SelectedDate!=null && time.Text!=null && time.Text!="" && shipType.SelectedIndex!=-1 && cargoType.SelectedIndex!=-1 && width.Text != null && width.Text != "" && length.Text != null && length.Text != "" && maxDraft.Text != null && maxDraft.Text != "" && shipOwner.Text != null && shipOwner.Text != "" && flag.SelectedIndex!=-1 && tonns>0 && size>0 && docImage!=null)
                        {
                            dtApp.Rows[appID - 1]["status"] = "Ожидает проверки судового агента";
                        }
                        else
                        {
                            dtApp.Rows[appID - 1]["status"] = "Не заполнено";
                        }

                        dtApp.Rows[appID - 1]["shipDocuments"] = documents.IsChecked;

                        if (rej1.IsChecked == true)
                        {
                            dtApp.Rows[appID - 1]["mode"] = "Погрузка";
                        }
                        else
                        {
                            dtApp.Rows[appID - 1]["mode"] = "Разгрузка";
                        }



                        SqlCommandBuilder cb = new SqlCommandBuilder(daApp);
                        daApp.Update(dtApp);

                        SqlDataAdapter Oda = new SqlDataAdapter("select * from application where ownerId=" + userID.ToString(), con);
                        DataTable Odt = new DataTable();
                        Oda.Fill(Odt);

                        open_clear();

                        for (int i = 0; i < Odt.Rows.Count; i++)
                        {
                            if (Convert.ToInt32(Odt.Rows[i]["id"]) != appID)
                            {
                                MenuItem appOpen = new MenuItem();
                                appOpen.Name = "O" + Odt.Rows[i]["id"].ToString();

                                appOpen.Header = Odt.Rows[i]["mode"].ToString();
                                if (Odt.Rows[i]["Date"].ToString() != "" && Odt.Rows[i]["Date"].ToString() != null)
                                    appOpen.Header += " " + Convert.ToDateTime(Odt.Rows[i]["Date"]).ToShortDateString();
                                appOpen.Visibility = Visibility.Visible;
                                appOpen.Click += Open_Click;
                                if (Odt.Rows[i]["status"].ToString() == "Не заполнено" || Odt.Rows[i]["status"].ToString() == "Готово" || Odt.Rows[i]["status"].ToString() == "Отказано")
                                {
                                    appOpen.Header += " " + Odt.Rows[i]["status"].ToString(); ;
                                    if (Odt.Rows[i]["status"].ToString() == "Не заполнено")
                                    {
                                        appOpen.Background = Brushes.Yellow;
                                    }
                                    if (Odt.Rows[i]["status"].ToString() == "Отказано")
                                    {
                                        appOpen.Background = Brushes.Red;
                                        renouncement.Header = "Причина отказа";
                                    }
                                }
                                else
                                {

                                    appOpen.Header += " Обрабатывается";
                                    appOpen.IsEnabled = false;
                                }
                                open.Items.Add(appOpen);
                            }
                        }

                        con.Close();

                        userTypeChanged("no");
                        #endregion
                        break;

                    case "agent":
                        if (appID != 0)
                        {
                            #region agent
                            SqlDataAdapter daBer = new SqlDataAdapter("select * from berthes", con);
                            DataTable dtBer = new DataTable();
                            daBer.Fill(dtBer);

                            SqlDataAdapter appDA = new SqlDataAdapter("select * from application", con);
                            DataTable appDT = new DataTable();
                            appDA.Fill(appDT);

                            foreach (DataRow row in pirsDT.Rows)
                            {
                                row[1] = "g";
                            }

                            for (int i = 0; i < dtBer.Rows.Count; i++)
                            {
                                for (int j = 0; j < appDT.Rows.Count; j++)
                                {
                                    if (appDT.Rows[j]["pier"].ToString() != "" && appDT.Rows[j]["pier"] != null)
                                    {
                                        if (appDT.Rows[j]["pier"].ToString() == dtBer.Rows[i]["№"].ToString() && date.SelectedDate.Value.ToShortDateString() == Convert.ToDateTime(appDT.Rows[j]["Date"]).ToShortDateString())
                                        {
                                            pirsDT.Rows[i][1] = "r";
                                            pirsDT.Rows[i][2] = "Причал занят";
                                        }
                                    }
                                }
                            }

                            for (int i = 0; i < dtBer.Rows.Count; i++)
                            {
                                if (pirsDT.Rows[i][1].ToString() != "r")
                                {
                                    bool g = false;
                                    string[] types = dtBer.Rows[i][2].ToString().Split(',');
                                    string[] sorts = dtBer.Rows[i][3].ToString().Split(',');
                                    switch (cargoType.SelectedValue.ToString())
                                    {
                                        case "Контейнер":
                                            for (int j = 0; j < types.Length; j++)
                                            {
                                                if (types[j] == "Контейнера" || types[j] == "Универсальный")
                                                    g = true;
                                            }
                                            break;
                                        case "Зерно":
                                            for (int j = 0; j < types.Length; j++)
                                            {
                                                string a = types[j];
                                                if (types[j] == @"Зерно\хим грузы" || types[j] == "Зерно и крупы" || types[j] == "Универсальный")
                                                    g = true;
                                            }
                                            break;
                                        case "Металл":
                                            for (int j = 0; j < types.Length; j++)
                                            {
                                                if (types[j] == "Металлопрокат" || types[j] == "металл бакалея" || types[j] == "Универсальный")
                                                    g = true;
                                            }
                                            for (int j = 0; j < sorts.Length; j++)
                                            {
                                                if (sorts[j] == "металл" || sorts[j] == "Металл")
                                                    g = true;
                                            }
                                            break;
                                        case "Сыпучий":
                                            for (int j = 0; j < types.Length; j++)
                                            {
                                                if (types[j] == @"Зерно\хим грузы" || types[j] == "Универсальный")
                                                    g = true;
                                            }
                                            break;
                                        case "Нефтепродукты":
                                            for (int j = 0; j < types.Length; j++)
                                            {
                                                if (types[j] == "Наливной" || types[j] == "Универсальный")
                                                    g = true;
                                            }
                                            break;
                                        case "Газ":
                                            for (int j = 0; j < types.Length; j++)
                                            {
                                                if (types[j] == "Наливной" || types[j] == "Универсальный")
                                                    g = true;
                                            }
                                            break;
                                        case "Лес":
                                            for (int j = 0; j < types.Length; j++)
                                            {
                                                if (types[j] == " разное" || types[j] == "Универсальный")
                                                    g = true;
                                            }
                                            break;
                                        case "Наливной":
                                            for (int j = 0; j < types.Length; j++)
                                            {
                                                if (types[j] == "Наливной" || types[j] == "Универсальный")
                                                    g = true;
                                            }
                                            break;
                                        case "Тарно-штучный груз":
                                            for (int j = 0; j < types.Length; j++)
                                            {
                                                 if (types[j] == "тарно-штучный груз" || types[j] == "Универсальный")
                                                    g = true;
                                            }
                                            break;
                                        case "Крытый грузы":
                                            for (int j = 0; j < types.Length; j++)
                                            {
                                                if (types[j] == "Крытый грузы" || types[j] == "Универсальный")
                                                    g = true;
                                            }
                                            break;
                                        case "Универсальный":
                                            for (int j = 0; j < types.Length; j++)
                                            {
                                                if (types[j] == "Универсальный")
                                                    g = true;
                                            }
                                            break;
                                    }

                                    if (!g)
                                    {
                                        pirsDT.Rows[i][1] = "r";
                                        pirsDT.Rows[i][2] = "Причал не потдерживает этот тип груза";
                                    }
                                }
                            }

                            for (int i = 0; i < dtBer.Rows.Count; i++)
                            {
                                if (pirsDT.Rows[i][1].ToString() != "r")
                                {
                                    if (Convert.ToDouble(length.Text) > Convert.ToDouble(dtBer.Rows[i]["lengthOfBerth"]))
                                    {
                                        pirsDT.Rows[i][1] = "y";
                                        pirsDT.Rows[i][2] = "Причал недостаточно длинный";
                                    }
                                    else
                                    {
                                        if (Convert.ToDouble(maxDraft.Text) > Convert.ToDouble(dtBer.Rows[i]["berthDepth"]))
                                        {
                                            pirsDT.Rows[i][1] = "y";
                                            pirsDT.Rows[i][2] = "Причал недостаточно глубокий";
                                        }
                                    }
                                }
                            }

                            for (int i = 0; i < dtBer.Rows.Count; i++)
                            {
                                if (pirsDT.Rows[i][1].ToString() != "r" && pirsDT.Rows[i][1].ToString() != "r")
                                {
                                    double capacity = Convert.ToDouble(dtBer.Rows[i]["terminalCapacity"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", ""));

                                    con.Open();

                                    SqlDataAdapter da = new SqlDataAdapter("select \"№\" from berthes where term=" + dtBer.Rows[i]["term"].ToString() + " and terminalCapacity='" + capacity.ToString() + "'", con);
                                    DataTable dt = new DataTable();
                                    da.Fill(dt);

                                    for (int j = 0; j < dt.Rows.Count; j++)
                                    {
                                        SqlDataAdapter da2 = new SqlDataAdapter("select cargoSize, cargoType from  application where pier=" + dt.Rows[j]["№"] + " and Date='" + date.SelectedDate.Value.ToShortDateString() + "'", con);
                                        DataTable dt2 = new DataTable();
                                        da2.Fill(dt2);

                                        for (int k = 0; k < dt2.Rows.Count; k++)
                                        {
                                            if (dt2.Rows[k]["cargoType"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "") == "Контейнер")
                                            {
                                                capacity -= teuToM3(Convert.ToDouble(dt2.Rows[k]["cargoSize"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", "")));
                                            }
                                            else
                                            {
                                                capacity -= Convert.ToDouble(dt2.Rows[k]["cargoSize"].ToString().Replace(Environment.NewLine, string.Empty).Replace(" ", ""));
                                            }
                                        }

                                    }

                                    con.Close();

                                    if (cargoType.SelectedValue.ToString() == "Контейнер")
                                    {
                                        if (m3ToTeu(size) > capacity)
                                        {
                                            pirsDT.Rows[i][1] = "y";
                                            pirsDT.Rows[i][2] = "Недочтаточно места для груза в терминале";
                                        }
                                    }
                                    else
                                    {
                                        if (size > capacity)
                                        {
                                            pirsDT.Rows[i][1] = "y";
                                            pirsDT.Rows[i][2] = "Недочтаточно места для груза в терминале";
                                        }
                                    }
                                }
                            }

                            string t1 = "r";

                            for (int i = 0; i < term1.Rows.Count; i++)
                            {
                                for (int j = 0; j < pirsDT.Rows.Count; j++)
                                {
                                    if (term1.Rows[i][0].ToString() == pirsDT.Rows[j][0].ToString())
                                    {
                                        DataGridRow row = (DataGridRow)pirsesGrid1.ItemContainerGenerator.ContainerFromIndex(i);

                                        if (pirsDT.Rows[j][1].ToString() == "g")
                                        {
                                            row.Background = Brushes.Green;
                                            t1 = "g";
                                            term1.Rows[i][1] = "Причал подходит";
                                        }
                                        else
                                        {
                                            if (pirsDT.Rows[j][1].ToString() == "y")
                                            {
                                                row.Background = Brushes.Yellow;

                                                if (t1 != "g")
                                                {
                                                    t1 = "y";
                                                }
                                            }
                                            else
                                            {
                                                row.Background = Brushes.Red;
                                            }
                                            term1.Rows[i][1] = pirsDT.Rows[j][2].ToString();
                                        }
                                    }
                                }
                            }

                            if (t1 == "g")
                            {
                                bTerm1.Background = Brushes.Green;
                            }
                            else
                            {
                                if (t1=="y")
                                    bTerm1.Background = Brushes.Yellow;
                                else
                                    bTerm1.Background = Brushes.Red;
                            }

                            string t2 = "r";
                            for (int i = 0; i < term2.Rows.Count; i++)
                            {
                                for (int j = 0; j < pirsDT.Rows.Count; j++)
                                {
                                    if (term2.Rows[i][0].ToString() == pirsDT.Rows[j][0].ToString())
                                    {
                                        DataGridRow row = (DataGridRow)pirsesGrid2.ItemContainerGenerator.ContainerFromIndex(i);

                                        if (pirsDT.Rows[j][1].ToString() == "g")
                                        {
                                            row.Background = Brushes.Green;
                                            t2 = "g";
                                            term2.Rows[i][1] = "Причал подходит";
                                        }
                                        else
                                        {
                                            if (pirsDT.Rows[j][1].ToString() == "y")
                                            {
                                                row.Background = Brushes.Yellow;

                                                if (t2 != "g")
                                                {
                                                    t2 = "y";
                                                }
                                            }
                                            else
                                            {
                                                row.Background = Brushes.Red;
                                            }
                                            term2.Rows[i][1] = pirsDT.Rows[j][2].ToString();
                                        }
                                    }
                                }
                            }

                            if (t2 == "g")
                            {
                                bTerm2.Background = Brushes.Green;
                            }
                            else
                            {
                                if (t2 == "y")
                                    bTerm2.Background = Brushes.Yellow;
                                else
                                    bTerm2.Background = Brushes.Red;
                            }

                            string t3 = "r";
                            for (int i = 0; i < term3.Rows.Count; i++)
                            {
                                for (int j = 0; j < pirsDT.Rows.Count; j++)
                                {
                                    if (term3.Rows[i][0].ToString() == pirsDT.Rows[j][0].ToString())
                                    {
                                        DataGridRow row = (DataGridRow)pirsesGrid3.ItemContainerGenerator.ContainerFromIndex(i);

                                        if (pirsDT.Rows[j][1].ToString() == "g")
                                        {
                                            row.Background = Brushes.Green;
                                            t3 = "g";
                                            term3.Rows[i][1] = "Причал подходит";
                                        }
                                        else
                                        {
                                            if (pirsDT.Rows[j][1].ToString() == "y")
                                            {
                                                row.Background = Brushes.Yellow;

                                                if (t3 != "g")
                                                {
                                                    t3 = "y";
                                                }
                                            }
                                            else
                                            {
                                                row.Background = Brushes.Red;
                                            }
                                            term3.Rows[i][1] = pirsDT.Rows[j][2].ToString();
                                        }
                                    }
                                }
                            }

                            if (t3 == "g")
                            {
                                bTerm3.Background = Brushes.Green;
                            }
                            else
                            {
                                if (t3 == "y")
                                    bTerm3.Background = Brushes.Yellow;
                                else
                                    bTerm3.Background = Brushes.Red;
                            }

                            string t4 = "r";
                            for (int i = 0; i < term4.Rows.Count; i++)
                            {
                                for (int j = 0; j < pirsDT.Rows.Count; j++)
                                {
                                    if (term4.Rows[i][0].ToString() == pirsDT.Rows[j][0].ToString())
                                    {
                                        DataGridRow row = (DataGridRow)pirsesGrid4.ItemContainerGenerator.ContainerFromIndex(i);

                                        if (pirsDT.Rows[j][1].ToString() == "g")
                                        {
                                            row.Background = Brushes.Green;
                                            t4 = "g";
                                            term4.Rows[i][1] = "Причал подходит";
                                        }
                                        else
                                        {
                                            if (pirsDT.Rows[j][1].ToString() == "y")
                                            {
                                                row.Background = Brushes.Yellow;

                                                if (t4 != "g")
                                                {
                                                    t4 = "y";
                                                }
                                            }
                                            else
                                            {
                                                row.Background = Brushes.Red;
                                            }
                                            term4.Rows[i][1] = pirsDT.Rows[j][2].ToString();
                                        }
                                    }
                                }
                            }

                            if (t4 == "g")
                            {
                                bTerm4.Background = Brushes.Green;
                            }
                            else
                            {
                                if (t4 == "y")
                                    bTerm4.Background = Brushes.Yellow;
                                else
                                    bTerm4.Background = Brushes.Red;
                            }

                            string t5 = "r";
                            for (int i = 0; i < term5.Rows.Count; i++)
                            {
                                for (int j = 0; j < pirsDT.Rows.Count; j++)
                                {
                                    if (term5.Rows[i][0].ToString() == pirsDT.Rows[j][0].ToString())
                                    {
                                        DataGridRow row = (DataGridRow)pirsesGrid5.ItemContainerGenerator.ContainerFromIndex(i);

                                        if (pirsDT.Rows[j][1].ToString() == "g")
                                        {
                                            row.Background = Brushes.Green;
                                            t5 = "g";
                                            term5.Rows[i][1] = "Причал подходит";
                                        }
                                        else
                                        {
                                            if (pirsDT.Rows[j][1].ToString() == "y")
                                            {
                                                row.Background = Brushes.Yellow;

                                                if (t5 != "g")
                                                {
                                                    t5 = "y";
                                                }
                                            }
                                            else
                                            {
                                                row.Background = Brushes.Red;
                                            }
                                            term5.Rows[i][1] = pirsDT.Rows[j][2].ToString();
                                        }
                                    }
                                }
                            }

                            if (t5 == "g")
                            {
                                bTerm5.Background = Brushes.Green;
                            }
                            else
                            {
                                if (t5 == "y")
                                    bTerm5.Background = Brushes.Yellow;
                                else
                                    bTerm5.Background = Brushes.Red;
                            }

                            string t6 = "r";
                            for (int i = 0; i < term6.Rows.Count; i++)
                            {
                                for (int j = 0; j < pirsDT.Rows.Count; j++)
                                {
                                    if (term6.Rows[i][0].ToString() == pirsDT.Rows[j][0].ToString())
                                    {
                                        DataGridRow row = (DataGridRow)pirsesGrid6.ItemContainerGenerator.ContainerFromIndex(i);

                                        if (pirsDT.Rows[j][1].ToString() == "g")
                                        {
                                            row.Background = Brushes.Green;
                                            t6 = "g";
                                            term6.Rows[i][1] = "Причал подходит";
                                        }
                                        else
                                        {
                                            if (pirsDT.Rows[j][1].ToString() == "y")
                                            {
                                                row.Background = Brushes.Yellow;

                                                if (t6 != "g")
                                                {
                                                    t6 = "y";
                                                }
                                            }
                                            else
                                            {
                                                row.Background = Brushes.Red;
                                            }
                                            term6.Rows[i][1] = pirsDT.Rows[j][2].ToString();
                                        }
                                    }
                                }
                            }

                            if (t6 == "g")
                            {
                                bTerm6.Background = Brushes.Green;
                            }
                            else
                            {
                                if(t6 == "y")
                                    bTerm6.Background = Brushes.Yellow;
                                else
                                    bTerm6.Background = Brushes.Red;
                            }

                            string t7 = "r";
                            for (int i = 0; i < term7.Rows.Count; i++)
                            {

                                for (int j = 0; j < pirsDT.Rows.Count; j++)
                                {
                                    if (term7.Rows[i][0].ToString() == pirsDT.Rows[j][0].ToString())
                                    {
                                        DataGridRow row = (DataGridRow)pirsesGrid7.ItemContainerGenerator.ContainerFromIndex(i);

                                        if (pirsDT.Rows[j][1].ToString() == "g")
                                        {
                                            row.Background = Brushes.Green;
                                            t7 = "g";
                                            term7.Rows[i][1] = "Причал подходит";
                                        }
                                        else
                                        {
                                            if (pirsDT.Rows[j][1].ToString() == "y")
                                            {
                                                row.Background = Brushes.Yellow;

                                                if (t7 != "g")
                                                {
                                                    t7 = "y";
                                                }
                                            }
                                            else
                                            {
                                                row.Background = Brushes.Red;
                                            }
                                            term7.Rows[i][1] = pirsDT.Rows[j][2].ToString();
                                        }
                                    }
                                }
                            }

                            if (t7 == "g")
                            {
                                bTerm7.Background = Brushes.Green;
                            }
                            else
                            {
                                if (t7 == "y")
                                    bTerm7.Background = Brushes.Yellow;
                                else
                                    bTerm7.Background = Brushes.Red;
                            }

                            string t8 = "r";
                            for (int i = 0; i < term8.Rows.Count; i++)
                            {
                                for (int j = 0; j < pirsDT.Rows.Count; j++)
                                {
                                    if (term8.Rows[i][0].ToString() == pirsDT.Rows[j][0].ToString())
                                    {
                                        DataGridRow row = (DataGridRow)pirsesGrid8.ItemContainerGenerator.ContainerFromIndex(i);


                                        if (pirsDT.Rows[j][1].ToString() == "g")
                                        {
                                            row.Background = Brushes.Green;
                                            t8 = "g";
                                            term8.Rows[i][1] = "Причал подходит";
                                        }
                                        else
                                        {
                                            if (pirsDT.Rows[j][1].ToString() == "y")
                                            {
                                                row.Background = Brushes.Yellow;

                                                if (t8 != "g")
                                                {
                                                    t8 = "y";
                                                }
                                            }
                                            else
                                            {
                                                row.Background = Brushes.Red;
                                            }
                                            term8.Rows[i][1] = pirsDT.Rows[j][2].ToString();
                                        }
                                    }
                                }
                            }
                            if (t8 == "g")
                            {
                                bTerm8.Background = Brushes.Green;
                            }
                            else
                            {
                                if (t8 == "y")
                                    bTerm8.Background = Brushes.Yellow;
                                else
                                    bTerm8.Background = Brushes.Red;
                            }


                            #endregion
                        }
                        break;
                }
            }
            catch
            {
                con.Close();
            }
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            registration reg = new registration(this, connectionString);
            reg.Show();
            this.IsEnabled = false;
        }

        private void login_Click(object sender, RoutedEventArgs e)
        {
            autorisation log = new autorisation(this, connectionString);
            log.Show();

            this.IsEnabled = false;
        }

        private void exit_Click(object sender, RoutedEventArgs e)
        {
            userTypeChanged("no");
        }

        private void doc_Click(object sender, RoutedEventArgs e)
        {
            if (userType == "cargoOwner")
            {
                addDoc doc = new addDoc(this);
                doc.Show();
            }
            else
            {
                showDoc doc = new showDoc(this);
                doc.Show();
            }
            this.IsEnabled = false;
        }

        private void weight_Click(object sender, RoutedEventArgs e)
        {
            if (userType == "cargoOwner")
            {
                setSize size = new setSize(this);
                size.Show();
                this.IsEnabled = false;
            }
            else
            {
                showSize size = new showSize(this);
                size.Show();
                this.IsEnabled = false;
            }
        }

        private void open_Click_1(object sender, RoutedEventArgs e)
        {
            if (userType == "agent")
            {
                calendar cal = new calendar(this, connectionString);
                cal.Show();
                cal.loadBack.Visibility = Visibility.Visible;
                cal.unloadBack.Visibility = Visibility.Visible;
                this.IsEnabled = false;
            }
        }

        private void termBack_Click(object sender, RoutedEventArgs e)
        {
            terminal1.Visibility = Visibility.Hidden;
            terminal2.Visibility = Visibility.Hidden;
            terminal3.Visibility = Visibility.Hidden;
            terminal4.Visibility = Visibility.Hidden;
            terminal5.Visibility = Visibility.Hidden;
            terminal6.Visibility = Visibility.Hidden;
            terminal7.Visibility = Visibility.Hidden;
            terminal8.Visibility = Visibility.Hidden;
            terminals.Visibility = Visibility.Visible;
        }

        private void bTerm1_Click(object sender, RoutedEventArgs e)
        {
            terminals.Visibility = Visibility.Hidden;
            terminal1.Visibility = Visibility.Visible;
        }

        private void bTerm2_Click(object sender, RoutedEventArgs e)
        {
            terminals.Visibility = Visibility.Hidden;
            terminal2.Visibility = Visibility.Visible;
        }

        private void bTerm3_Click(object sender, RoutedEventArgs e)
        {
            terminals.Visibility = Visibility.Hidden;
            terminal3.Visibility = Visibility.Visible;
        }

        private void bTerm4_Click(object sender, RoutedEventArgs e)
        {
            terminals.Visibility = Visibility.Hidden;
            terminal4.Visibility = Visibility.Visible;
        }

        private void bTerm5_Click(object sender, RoutedEventArgs e)
        {
            terminals.Visibility = Visibility.Hidden;
            terminal5.Visibility = Visibility.Visible;
        }

        private void bTerm6_Click(object sender, RoutedEventArgs e)
        {
            terminals.Visibility = Visibility.Hidden;
            terminal6.Visibility = Visibility.Visible;
        }

        private void bTerm7_Click(object sender, RoutedEventArgs e)
        {
            terminals.Visibility = Visibility.Hidden;
            terminal7.Visibility = Visibility.Visible;
        }

        private void bTerm8_Click(object sender, RoutedEventArgs e)
        {
            terminals.Visibility = Visibility.Hidden;
            terminal8.Visibility = Visibility.Visible;
        }

        private void stock_Click(object sender, RoutedEventArgs e)
        {
            stocks stocks = new stocks(this, connectionString);
            stocks.Show();
            this.IsEnabled = false;
        }

        private void look8_Click(object sender, RoutedEventArgs e)
        {
            if (pirsesGrid8.SelectedIndex != -1)
            {
                bool enable = false;
                if (term8.Rows[pirsesGrid8.SelectedIndex][1].ToString() == "Причал подходит")
                {
                    enable = true;
                }

                prichal prich = new prichal(this, connectionString, term8.Rows[pirsesGrid8.SelectedIndex][0].ToString(), enable);
                prich.Show();
                this.IsEnabled = false;
            }
        }

        private void look7_Click(object sender, RoutedEventArgs e)
        {
            if (pirsesGrid7.SelectedIndex != -1)
            {
                bool enable = false;
                if (term7.Rows[pirsesGrid7.SelectedIndex][1].ToString() == "Причал подходит")
                {
                    enable = true;
                }

                prichal prich = new prichal(this, connectionString, term7.Rows[pirsesGrid7.SelectedIndex][0].ToString(), enable);
                prich.Show();
                this.IsEnabled = false;
            }
        }

        private void look6_Click(object sender, RoutedEventArgs e)
        {
            if (pirsesGrid6.SelectedIndex != -1)
            {
                bool enable = false;
                if (term6.Rows[pirsesGrid6.SelectedIndex][1].ToString() == "Причал подходит")
                {
                    enable = true;
                }

                prichal prich = new prichal(this, connectionString, term6.Rows[pirsesGrid6.SelectedIndex][0].ToString(), enable);
                prich.Show();
                this.IsEnabled = false;
            }
        }

        private void look5_Click(object sender, RoutedEventArgs e)
        {
            if (pirsesGrid5.SelectedIndex != -1)
            {
                bool enable = false;
                if (term5.Rows[pirsesGrid5.SelectedIndex][1].ToString() == "Причал подходит")
                {
                    enable = true;
                }

                prichal prich = new prichal(this, connectionString, term5.Rows[pirsesGrid5.SelectedIndex][0].ToString(), enable);
                prich.Show();
                this.IsEnabled = false;
            }
        }

        private void look4_Click(object sender, RoutedEventArgs e)
        {
            if (pirsesGrid4.SelectedIndex != -1)
            {
                bool enable = false;
                if (term4.Rows[pirsesGrid4.SelectedIndex][1].ToString() == "Причал подходит")
                {
                    enable = true;
                }

                prichal prich = new prichal(this, connectionString, term4.Rows[pirsesGrid4.SelectedIndex][0].ToString(), enable);
                prich.Show();
                this.IsEnabled = false;
            }
        }

        private void look3_Click(object sender, RoutedEventArgs e)
        {
            if (pirsesGrid3.SelectedIndex != -1)
            {
                bool enable = false;
                if (term3.Rows[pirsesGrid3.SelectedIndex][1].ToString() == "Причал подходит")
                {
                    enable = true;
                }

                prichal prich = new prichal(this, connectionString, term3.Rows[pirsesGrid3.SelectedIndex][0].ToString(), enable);
                prich.Show();
                this.IsEnabled = false;
            }
        }

        private void look2_Click(object sender, RoutedEventArgs e)
        {
            if (pirsesGrid2.SelectedIndex != -1)
            {
                bool enable = false;
                if (term2.Rows[pirsesGrid2.SelectedIndex][1].ToString() == "Причал подходит")
                {
                    enable = true;
                }

                prichal prich = new prichal(this, connectionString, term2.Rows[pirsesGrid2.SelectedIndex][0].ToString(), enable);
                prich.Show();
                this.IsEnabled = false;
            }
        }

        private void look1_Click(object sender, RoutedEventArgs e)
        {
            if (pirsesGrid1.SelectedIndex != -1)
            {
                bool enable = false;
                if (term1.Rows[pirsesGrid1.SelectedIndex][1].ToString() == "Причал подходит")
                {
                    enable = true;
                }


                prichal prich = new prichal(this, connectionString, term1.Rows[pirsesGrid1.SelectedIndex][0].ToString(), enable);
                prich.Show();
                this.IsEnabled = false;
            }
        }

        public double m3ToTeu(double m)
        {
            double teu = (m / 2.44 / 2.59) / 6.1;
            return teu;
        }

        public double teuToM3(double teu)
        {
            double m = teu * 2.44 * 2.59 * 6.1;
            return m;
        }

        private void price_Click(object sender, RoutedEventArgs e)
        {
            switch(userType)
            {
                case "cargoOwner":
                    chekPrixe chP = new chekPrixe(this, connectionString);
                    chP.Show();
                    this.IsEnabled = false;
                    break;
                case "agent":
                    agentSetPrise price = new agentSetPrise(this, connectionString);
                    price.Show();
                    this.IsEnabled = false;
                    break;
                case "warehousingSevise":
                    storePrice store = new storePrice(this, connectionString);
                    store.Show();
                    this.IsEnabled = false;
                    break;
                case "customerService":
                    servisePrice ser = new servisePrice(this, connectionString);
                    ser.Show();
                    this.IsEnabled = false;
                    break;

            }
        }

        private void servises_Click(object sender, RoutedEventArgs e)
        {
            servises ser = new servises(this, connectionString);
            ser.Show();
            this.IsEnabled = false;
        }

        private void tehnick_Click(object sender, RoutedEventArgs e)
        {
            tehnik teh = new tehnik(this, connectionString);
            teh.Show();
            this.IsEnabled = false;
        }

        private void renouncement_Click(object sender, RoutedEventArgs e)
        {
            if (userType=="cargoOwner")
            {
                string id = appID.ToString();
                rejectionReason rej = new rejectionReason(this, connectionString, id);
                rej.Show();
                this.IsEnabled = true;
            }
            if (userType == "agent")
            {
                Refuse refuse = new Refuse(this, connectionString);
                refuse.Show();
                this.IsEnabled = false;
            }
        }

        private void date_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            if (userType == "cargoOwner")
            {
                if (date.SelectedDate != null)
                    dateTo.DisplayDateStart = date.SelectedDate.Value.AddDays(2);
                else
                {
                    dateTo.DisplayDateStart = date.DisplayDateStart.Value.AddDays(2);
                    date.DisplayDateStart = DateTime.Today;
                }
            }
        }

        private void dateTo_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            if (userType == "cargoOwner")
            {
                if (dateTo.SelectedDate != null)
                    date.DisplayDateEnd = dateTo.SelectedDate.Value.AddDays(-2);
                else
                    date.DisplayDateEnd = null;
            }
        }

        private void _new_Click(object sender, RoutedEventArgs e)
        {
            appID = 0;
            tonns = 0;
            size = 0;
            agentPrice = 0;
            docImage = null;
            date.SelectedDate = null;
            dateTo.SelectedDate = null;
            time.Text = "";
            shipOwner.Text = "";
            width.Text = "";
            length.Text = "";
            maxDraft.Text = "";
            documents.IsChecked = false;
            shipType.SelectedIndex = -1;
            cargoType.SelectedIndex = -1;
            flag.SelectedIndex = -1;

            open_clear();

            con.Open();

            SqlDataAdapter da = new SqlDataAdapter("select * from application where ownerId=" + userID.ToString(), con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (Convert.ToInt32(dt.Rows[i]["id"]) != appID)
                {
                    MenuItem appOpen = new MenuItem();
                    appOpen.Name = "O" + dt.Rows[i]["id"].ToString();

                    appOpen.Header = dt.Rows[i]["mode"].ToString();
                    if (dt.Rows[i]["Date"].ToString() != "" && dt.Rows[i]["Date"].ToString() != null)
                        appOpen.Header += " " + Convert.ToDateTime(dt.Rows[i]["Date"]).ToShortDateString();
                    appOpen.Visibility = Visibility.Visible;
                    appOpen.Click += Open_Click;
                    if (dt.Rows[i]["status"].ToString() == "Не заполнено" || dt.Rows[i]["status"].ToString() == "Готово" || dt.Rows[i]["status"].ToString() == "Отказано")
                    {
                        appOpen.Header += " " + dt.Rows[i]["status"].ToString(); ;
                        if (dt.Rows[i]["status"].ToString() == "Не заполнено")
                        {
                            appOpen.Background = Brushes.Yellow;
                        }
                        if (dt.Rows[i]["status"].ToString() == "Отказано")
                        {
                            appOpen.Background = Brushes.Red;
                            renouncement.Header = "Причина отказа";
                        }
                    }
                    else
                    {

                        appOpen.Header += " Обрабатывается";
                        appOpen.IsEnabled = false;
                    }
                    open.Items.Add(appOpen);

                    price.IsEnabled = false;
                    ship.IsEnabled = true;
                    cargo.IsEnabled = true;
                    ok.IsEnabled = true;
                }
            }

            con.Close();
        }
    }
}
